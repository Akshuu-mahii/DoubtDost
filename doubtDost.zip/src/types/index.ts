/**
 * Doubt Dost - Core Type Definitions
 */

export interface UserProfile {
  name: string;
  preferredLanguage: string; // 'Auto-detect' | 'English' | 'Tamil' | 'Tanglish'
  level: string; // 'Class 9-10' | 'Class 11-12' | 'College / Engineering' | 'Self-learner'
  learningStyle?: string;
  onboardingComplete: boolean;
  interests: string[];
  privacyConsentAccepted?: boolean;
  trustedContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  pauseSaving: boolean;
  createdAt: string;
  updatedAt: string;
}

export type AnswerStyle = 'Detailed lesson' | '2-mark' | '5-mark' | '10-mark' | 'Quick revision';

export type LearningModelType =
  | 'gemini-flash'
  | 'deep-reasoning'
  | 'socratic-tutor'
  | 'exam-specialist'
  | 'tanglish-bilingual'
  | 'story-analogy'
  | 'quick-doubt';

export interface ModelTypeOption {
  id: LearningModelType;
  name: string;
  badge: string;
  icon: string;
  tagline: string;
  description: string;
  speed: 'Ultra Fast' | 'Fast' | 'Deep Think';
  bestFor: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  style?: AnswerStyle;
  modelType?: LearningModelType;
  language?: string;
  tryFirst?: boolean;
  revealed?: boolean;
  feedback?: 'positive' | 'negative' | null;
  truthCheckStatus?: 'Verified' | 'Partly verified' | 'Not verified' | 'General answer, not from your notes';
  truthCheckSources?: string[];
  truthCheckNotesCount?: number;
  truthCheckExplanation?: string;
  timestamp: string;
  activeAgents?: string[];
  streaming?: boolean;
  quizPreGenerated?: any;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
}

export interface UserNote {
  id: string;
  title: string;
  content: string;
  chunks: string[];
  chunksCount: number;
  uploadedAt: string;
  fileType: string;
  size: number;
}

export interface QuizQuestion {
  id: number;
  type: 'mcq' | 'true_false' | 'fill_blank' | 'short_answer' | 'scenario';
  difficulty: 'Easy' | 'Medium' | 'Hard';
  question: string;
  options: string[] | null;
  correctAnswer: string;
  explanation: string;
  conceptTested: string;
}

export interface QuizResult {
  id: string;
  topic: string;
  score: number;
  totalQuestions: number;
  beforeConfidence: number;
  afterConfidence: number;
  strongConcepts: string[];
  weakConcepts: string[];
  date: string;
}

export interface MistakeItem {
  id: string;
  topic: string;
  question: string;
  userAnswer: string;
  correctAnswer: string;
  explanation: string;
  reviewed: boolean;
  date: string;
}

export interface StudyPlanItem {
  id: string;
  day: string; // e.g. 'Monday', 'Tuesday', or 'Today'
  topic: string;
  task: string;
  status: 'pending' | 'completed';
  approved: boolean;
  origin: 'planner_agent' | 'user';
  createdAt: string;
}

export interface MoodCheckin {
  id: string;
  mood: string; // emoji e.g. '😊', '😐', '😔', '😤', '😴'
  moodLabel: string;
  note?: string;
  reply: string;
  timestamp: string;
}

export interface ActionLog {
  id: string;
  agentName: string;
  actionDescription: string;
  status: 'suggested' | 'approved' | 'rejected' | 'completed' | 'in_progress' | 'failed' | 'pending';
  timestamp: string;
}

export interface AgentActivityState {
  tutor: 'idle' | 'active' | 'streaming';
  truthCheck: 'idle' | 'active' | 'done';
  quiz: 'idle' | 'pre-generating' | 'ready';
  planner: 'idle' | 'active' | 'done';
  safety: 'active' | 'flagged';
  voiceTutor?: 'idle' | 'speaking';
  visualLesson?: 'idle' | 'generating' | 'ready';
}
