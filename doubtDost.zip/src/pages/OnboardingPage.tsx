/**
 * DoubtDost - Student Onboarding & Setup Screen
 * Fully visible and scrollable responsive layout across all viewports (360x640 to 1920x1080)
 * and zoom levels (125%, 150%).
 * No fixed heights or overflow clipping; sticky bottom action footer.
 * Pure frontend: zero prefilled fake data, saved only in this browser (localStorage).
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  CheckCircle2,
  Shield,
  HeartHandshake,
  BookOpen,
  Globe2,
  ArrowRight,
  Brain,
  Compass,
  Check,
} from 'lucide-react';

const LANGUAGE_OPTIONS = [
  { id: 'Auto-detect', title: 'Auto-detect', desc: 'Replies in the language you type (English, Tamil, Tanglish)' },
  { id: 'English', title: 'English', desc: 'Clear, structured academic English' },
  { id: 'Tamil', title: 'தமிழ் (Tamil)', desc: 'Pure and standard Tamil explanations' },
  { id: 'Tanglish', title: 'Tanglish', desc: 'Conversational Tamil + English blend (friendly study tone)' },
];

const LEVEL_OPTIONS = [
  'Class 9-10 (Secondary)',
  'Class 11-12 / HSC (Higher Secondary)',
  'College / Engineering / Science',
  'Competitive Exam Prep (NEET / JEE / UPSC)',
  'General / Self-directed Learner',
];

const LEARNING_STYLES = [
  {
    id: 'Detailed & Step-by-Step',
    title: 'Detailed & Step-by-Step',
    desc: 'Structured 8-part notes, worked examples, comparison tables, and recap.',
  },
  {
    id: 'Socratic Guidance',
    title: 'Socratic Guidance',
    desc: 'Never gives the answer away; asks guiding questions and provides hints first.',
  },
  {
    id: 'Exam & Marks Focused',
    title: 'Exam & Marks Focused',
    desc: 'Highlights key buzzwords, marking criteria, and common deduction traps.',
  },
  {
    id: 'Tanglish Conversational',
    title: 'Tanglish Conversational',
    desc: 'Explains complex concepts in a warm Tamil-English blend like a study friend.',
  },
];

const AVAILABLE_INTERESTS = [
  '🏏 Cricket',
  '⚽ Football',
  '💻 Tech & Coding',
  '⚔️ Anime',
  '🎬 Movies',
  '🎵 Music',
  '🎮 Gaming',
  '🍳 Cooking',
  '🎨 Art & Design',
  '✈️ Travel',
  '📖 Stories',
  '😂 Memes',
];

export const OnboardingPage: React.FC = () => {
  const { profile, completeOnboarding } = useApp();

  // Form fields (no fake or pre-filled data!)
  const [name, setName] = useState<string>(profile.name || '');
  const [preferredLanguage, setPreferredLanguage] = useState<string>(profile.preferredLanguage || 'Auto-detect');
  const [level, setLevel] = useState<string>(profile.level || 'Class 11-12 / HSC (Higher Secondary)');
  const [learningStyle, setLearningStyle] = useState<string>(profile.learningStyle || 'Detailed & Step-by-Step');
  const [interests, setInterests] = useState<string[]>(profile.interests || []);
  const [privacyConsent, setPrivacyConsent] = useState<boolean>(true);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);

  const toggleInterest = (interest: string) => {
    setInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handleStartLearning = () => {
    if (!name.trim()) {
      setErrorNotice('Please enter your name so DoubtDost knows what to call you.');
      return;
    }

    if (!privacyConsent) {
      setErrorNotice('Please acknowledge the privacy notice to start learning.');
      return;
    }

    completeOnboarding({
      name: name.trim(),
      preferredLanguage,
      level,
      learningStyle,
      interests,
      privacyConsentAccepted: true,
    });
  };

  return (
    <div className="min-h-dvh w-full overflow-y-auto bg-gradient-to-br from-violet-50/70 via-indigo-50/40 to-teal-50/50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950/40 text-slate-800 dark:text-slate-100 px-4 md:px-6 py-6 md:py-10 flex flex-col items-center">
      {/* 1. Header (Logo & Subtitle) */}
      <header className="w-full max-w-3xl mb-4 sm:mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-500 to-indigo-600 flex items-center justify-center text-white shadow-sm shadow-teal-500/20">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-lg text-slate-900 dark:text-white">DoubtDost</span>
            <span className="text-xs text-slate-400 block -mt-1">டவுட் தோஸ்த்</span>
          </div>
        </div>

        <span className="text-xs text-teal-600 dark:text-teal-400 font-semibold bg-teal-500/10 px-2.5 py-1 rounded-full border border-teal-500/20">
          No sign-in needed
        </span>
      </header>

      {/* 2. Main Setup Card (Responsive, grows with content, no fixed pixel widths) */}
      <main className="w-full max-w-3xl">
        <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-xl shadow-indigo-500/5 p-4 sm:p-6 md:p-8 space-y-6 relative">
          {/* Welcome Intro */}
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-700 dark:text-teal-300 text-xs font-semibold mb-2 border border-teal-500/20">
              <HeartHandshake className="w-3.5 h-3.5" />
              Welcome to DoubtDost
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
              Your friendly AI study companion
            </h1>
            <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Ask doubts, understand tough lessons, take diagnostic quizzes, and track your mastery.
            </p>
          </div>

          {errorNotice && (
            <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs flex items-center gap-2">
              <span className="text-base">⚠️</span>
              <span>{errorNotice}</span>
            </div>
          )}

          {/* Field 1: Name */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              What is your name? <span className="text-teal-600 font-bold">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setErrorNotice(null);
              }}
              placeholder="e.g. Akshaya"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/40"
            />
          </div>

          {/* Field 2: Language & Tone Preference */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5">
              <Globe2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Language & Tone Preference
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {LANGUAGE_OPTIONS.map((opt) => (
                <button
                  type="button"
                  key={opt.id}
                  onClick={() => setPreferredLanguage(opt.id)}
                  className={`text-left p-3 rounded-2xl border transition cursor-pointer flex flex-col justify-between ${
                    preferredLanguage === opt.id
                      ? 'border-teal-500 bg-teal-500/10 dark:bg-teal-500/15 ring-1 ring-teal-500/30'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-xs text-slate-900 dark:text-white">{opt.title}</span>
                    {preferredLanguage === opt.id && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                    )}
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">{opt.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Field 3: Class or Level */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Class or Study Level
              </label>
            </div>
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
            >
              {LEVEL_OPTIONS.map((lvl) => (
                <option key={lvl} value={lvl}>
                  {lvl}
                </option>
              ))}
            </select>
          </div>

          {/* Field 4: Learning Style */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5">
              <Brain className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Preferred Learning Style
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {LEARNING_STYLES.map((style) => (
                <button
                  type="button"
                  key={style.id}
                  onClick={() => setLearningStyle(style.id)}
                  className={`text-left p-3 rounded-2xl border transition cursor-pointer flex flex-col justify-between ${
                    learningStyle === style.id
                      ? 'border-indigo-500 bg-indigo-500/10 dark:bg-indigo-500/15 ring-1 ring-indigo-500/30'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-xs text-slate-900 dark:text-white">{style.title}</span>
                    {learningStyle === style.id && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    )}
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">{style.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Field 5: Interests & Hobbies (used in relatable examples) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Your Interests & Hobbies (Optional)
                </label>
              </div>
              <span className="text-[11px] text-slate-400">
                {interests.length > 0 ? `${interests.length} selected` : 'Pick any you like'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 -mt-1">
              DoubtDost will use these to create memorable analogies and real-life examples for you.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {AVAILABLE_INTERESTS.map((interest) => {
                const selected = interests.includes(interest);
                return (
                  <button
                    type="button"
                    key={interest}
                    onClick={() => toggleInterest(interest)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition cursor-pointer flex items-center gap-1.5 border ${
                      selected
                        ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    <span>{interest}</span>
                    {selected && <Check className="w-3 h-3 stroke-[3]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Field 6: Privacy Note & Consent */}
          <div className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/70 dark:border-indigo-800/40 text-xs text-slate-600 dark:text-slate-300 space-y-3 leading-relaxed">
            <div className="flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <strong className="text-indigo-950 dark:text-indigo-200 block">
                  A Few Things to Know About DoubtDost:
                </strong>
                <p>
                  • <strong>Your data is saved only in this browser (localStorage).</strong> No sign-in, no remote database, no advertising cookies, and no tracking.
                </p>
                <p>
                  • <strong>I&apos;m an AI learning companion, not a therapist or doctor.</strong> If you ever feel distressed, I will provide warm helpline resources.
                </p>
                <p>
                  • You can pause saving (&quot;Incognito mode&quot;) or delete all your data anytime in Settings.
                </p>
              </div>
            </div>

            <label className="flex items-start gap-2.5 pt-1 border-t border-indigo-200/50 dark:border-indigo-800/30 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={privacyConsent}
                onChange={(e) => {
                  setPrivacyConsent(e.target.checked);
                  setErrorNotice(null);
                }}
                className="mt-0.5 w-4 h-4 rounded text-teal-600 focus:ring-teal-500 border-slate-300 dark:border-slate-600"
              />
              <span className="text-[11px] text-slate-700 dark:text-slate-300 font-medium">
                I understand that DoubtDost saves my data only in this browser and agree to these guidelines.
              </span>
            </label>
          </div>

          {/* Sticky Footer inside the card: Always reachable & visible without scrolling to the end */}
          <div className="sticky bottom-0 z-20 -mx-4 -mb-4 sm:-mx-6 sm:-mb-6 md:-mx-8 md:-mb-8 px-4 py-3 sm:px-6 sm:py-3.5 md:px-8 md:py-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 rounded-b-3xl shadow-lg flex items-center justify-between gap-3">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:inline">
              Ready to learn? Your workspace starts fresh.
            </span>

            <button
              type="button"
              onClick={handleStartLearning}
              className="w-full sm:w-auto flex-1 sm:flex-none flex items-center justify-center gap-2 py-3 px-6 rounded-2xl bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 text-white font-semibold text-sm transition shadow-lg shadow-teal-500/15 cursor-pointer active:scale-98"
            >
              <span>Start Learning with DoubtDost</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </main>

      {/* Bottom Footer Note */}
      <footer className="w-full max-w-3xl mt-4 sm:mt-6 text-center text-xs text-slate-400 dark:text-slate-500">
        DoubtDost • AI Learning Companion • All data stored locally in your browser
      </footer>
    </div>
  );
};
