/**
 * Doubt Dost - Application State Context
 * Pure frontend state backed 100% by browser localStorage.
 * No sign-in, no remote server, zero Firebase.
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  UserProfile,
  ChatSession,
  ChatMessage,
  UserNote,
  QuizResult,
  MistakeItem,
  StudyPlanItem,
  MoodCheckin,
  ActionLog,
} from '../types';
import { StorageService, DEFAULT_PROFILE } from '../services/storage';

interface AppContextType {
  profile: UserProfile;
  updateProfile: (data: Partial<UserProfile>) => void;
  completeOnboarding: (data: {
    name: string;
    preferredLanguage: string;
    level: string;
    learningStyle?: string;
    interests?: string[];
    privacyConsentAccepted?: boolean;
  }) => void;
  chats: ChatSession[];
  currentChatId: string;
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  notes: UserNote[];
  quizzes: QuizResult[];
  mistakes: MistakeItem[];
  studyPlan: StudyPlanItem[];
  checkins: MoodCheckin[];
  actionLogs: ActionLog[];
  createNewChat: () => void;
  selectChat: (chatId: string) => void;
  deleteCurrentChat: () => void;
  deleteAllData: () => void;
  addNote: (title: string, content: string, fileType: string, size: number) => void;
  deleteNote: (id: string) => void;
  addQuizResult: (res: Omit<QuizResult, 'id' | 'date'>) => void;
  addMistake: (mistake: Omit<MistakeItem, 'id' | 'date'>) => void;
  reviewMistake: (id: string) => void;
  deleteMistake: (id: string) => void;
  addPlanTask: (task: Omit<StudyPlanItem, 'id' | 'createdAt'>) => void;
  approvePlanTask: (id: string) => void;
  rejectPlanTask: (id: string) => void;
  togglePlanTask: (id: string) => void;
  deletePlanTask: (id: string) => void;
  addCheckin: (mood: string, moodLabel: string, note?: string) => string;
  logAgentAction: (agentName: string, actionDescription: string, status?: ActionLog['status']) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // State from LocalStorage
  const [profile, setProfile] = useState<UserProfile>(() => StorageService.getProfile());
  const [chats, setChats] = useState<ChatSession[]>(() => StorageService.getChats());
  const [currentChatId, setCurrentChatId] = useState<string>(() => {
    const savedChats = StorageService.getChats();
    return savedChats.length > 0 ? savedChats[0].id : 'chat_default';
  });
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const savedChats = StorageService.getChats();
    const id = savedChats.length > 0 ? savedChats[0].id : 'chat_default';
    return StorageService.getMessages(id);
  });
  const [notes, setNotes] = useState<UserNote[]>(() => StorageService.getNotes());
  const [quizzes, setQuizzes] = useState<QuizResult[]>(() => StorageService.getQuizzes());
  const [mistakes, setMistakes] = useState<MistakeItem[]>(() => StorageService.getMistakes());
  const [studyPlan, setStudyPlan] = useState<StudyPlanItem[]>(() => StorageService.getPlan());
  const [checkins, setCheckins] = useState<MoodCheckin[]>(() => StorageService.getCheckins());
  const [actionLogs, setActionLogs] = useState<ActionLog[]>(() => StorageService.getLogs());

  // Save changes to localStorage
  useEffect(() => {
    StorageService.saveProfile(profile);
  }, [profile]);

  useEffect(() => {
    StorageService.saveChats(chats);
  }, [chats]);

  useEffect(() => {
    if (currentChatId) {
      StorageService.saveMessages(currentChatId, messages);
    }
  }, [currentChatId, messages]);

  useEffect(() => {
    StorageService.saveNotes(notes);
  }, [notes]);

  useEffect(() => {
    StorageService.saveQuizzes(quizzes);
  }, [quizzes]);

  useEffect(() => {
    StorageService.saveMistakes(mistakes);
  }, [mistakes]);

  useEffect(() => {
    StorageService.savePlan(studyPlan);
  }, [studyPlan]);

  useEffect(() => {
    StorageService.saveCheckins(checkins);
  }, [checkins]);

  useEffect(() => {
    StorageService.saveLogs(actionLogs);
  }, [actionLogs]);

  // Actions
  const updateProfile = useCallback((data: Partial<UserProfile>) => {
    setProfile((prev) => ({
      ...prev,
      ...data,
      updatedAt: new Date().toISOString(),
    }));
  }, []);

  const completeOnboarding = useCallback(
    ({
      name,
      preferredLanguage,
      level,
      learningStyle,
      interests,
      privacyConsentAccepted,
    }: {
      name: string;
      preferredLanguage: string;
      level: string;
      learningStyle?: string;
      interests?: string[];
      privacyConsentAccepted?: boolean;
    }) => {
      setProfile((prev) => ({
        ...prev,
        name: name.trim(),
        preferredLanguage,
        level,
        learningStyle: learningStyle || prev.learningStyle,
        interests: interests !== undefined ? interests : prev.interests,
        privacyConsentAccepted: privacyConsentAccepted !== undefined ? privacyConsentAccepted : true,
        onboardingComplete: true,
        updatedAt: new Date().toISOString(),
      }));
    },
    []
  );

  const createNewChat = useCallback(() => {
    const newId = `chat_${Date.now()}`;
    const newSession: ChatSession = {
      id: newId,
      title: 'New Study Session',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messageCount: 0,
    };
    setChats((prev) => [newSession, ...prev]);
    setCurrentChatId(newId);
    setMessages([]);
  }, []);

  const selectChat = useCallback((chatId: string) => {
    setCurrentChatId(chatId);
    setMessages(StorageService.getMessages(chatId));
  }, []);

  const deleteCurrentChat = useCallback(() => {
    StorageService.deleteChatMessages(currentChatId);
    setChats((prev) => prev.filter((c) => c.id !== currentChatId));
    setMessages([]);
    const remaining = chats.filter((c) => c.id !== currentChatId);
    if (remaining.length > 0) {
      setCurrentChatId(remaining[0].id);
      setMessages(StorageService.getMessages(remaining[0].id));
    } else {
      const fallbackId = `chat_${Date.now()}`;
      setCurrentChatId(fallbackId);
    }
  }, [currentChatId, chats]);

  const deleteAllData = useCallback(() => {
    StorageService.clearAll();
    setProfile(DEFAULT_PROFILE);
    setChats([]);
    setMessages([]);
    setNotes([]);
    setQuizzes([]);
    setMistakes([]);
    setStudyPlan([]);
    setCheckins([]);
    setActionLogs([]);
    setCurrentChatId('chat_default');
  }, []);

  // Notes
  const addNote = useCallback((title: string, content: string, fileType: string, size: number) => {
    // Semantic paragraph chunking
    const paragraphs = content.split(/\n\s*\n/);
    const chunks: string[] = [];
    let currentChunk = '';
    for (const p of paragraphs) {
      if ((currentChunk + '\n' + p).length < 1200) {
        currentChunk += (currentChunk ? '\n\n' : '') + p;
      } else {
        if (currentChunk) chunks.push(currentChunk);
        currentChunk = p;
      }
    }
    if (currentChunk) chunks.push(currentChunk);

    const newNote: UserNote = {
      id: `note_${Date.now()}`,
      title,
      content,
      chunks,
      chunksCount: chunks.length,
      uploadedAt: new Date().toLocaleDateString(),
      fileType,
      size,
    };

    setNotes((prev) => [newNote, ...prev]);
  }, []);

  const deleteNote = useCallback((id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  }, []);

  // Quizzes & Mistakes
  const addQuizResult = useCallback((res: Omit<QuizResult, 'id' | 'date'>) => {
    const newQuiz: QuizResult = {
      ...res,
      id: `quiz_${Date.now()}`,
      date: new Date().toLocaleDateString(),
    };
    setQuizzes((prev) => [newQuiz, ...prev]);
  }, []);

  const addMistake = useCallback((mistake: Omit<MistakeItem, 'id' | 'date'>) => {
    const newMistake: MistakeItem = {
      ...mistake,
      id: `mistake_${Date.now()}`,
      date: new Date().toLocaleDateString(),
    };
    setMistakes((prev) => [newMistake, ...prev]);
  }, []);

  const reviewMistake = useCallback((id: string) => {
    setMistakes((prev) =>
      prev.map((m) => (m.id === id ? { ...m, reviewed: true } : m))
    );
  }, []);

  const deleteMistake = useCallback((id: string) => {
    setMistakes((prev) => prev.filter((m) => m.id !== id));
  }, []);

  // Study Plan
  const addPlanTask = useCallback((task: Omit<StudyPlanItem, 'id' | 'createdAt'>) => {
    const newTask: StudyPlanItem = {
      ...task,
      id: `plan_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setStudyPlan((prev) => [newTask, ...prev]);
  }, []);

  const approvePlanTask = useCallback((id: string) => {
    setStudyPlan((prev) =>
      prev.map((t) => (t.id === id ? { ...t, approved: true } : t))
    );
  }, []);

  const rejectPlanTask = useCallback((id: string) => {
    setStudyPlan((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const togglePlanTask = useCallback((id: string) => {
    setStudyPlan((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, status: t.status === 'completed' ? 'pending' : 'completed' } : t
      )
    );
  }, []);

  const deletePlanTask = useCallback((id: string) => {
    setStudyPlan((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Friend Checkins
  const addCheckin = useCallback((mood: string, moodLabel: string, note?: string): string => {
    let reply = 'Thank you for taking a moment to check in with yourself. Learning is a marathon, not a sprint!';
    if (['😓', '😔', '😤'].includes(mood)) {
      reply =
        "It's completely normal to feel stretched or low during study periods. Give yourself permission to pause, take a deep breath, and drink some water.";
    } else if (['🌟', '😊'].includes(mood)) {
      reply =
        'Great energy! Harness this momentum while keeping steady focus. Remember to take 5-minute pauses between tough topics.';
    }

    const newCheckin: MoodCheckin = {
      id: `checkin_${Date.now()}`,
      mood,
      moodLabel,
      note,
      reply,
      timestamp: new Date().toISOString(),
    };

    setCheckins((prev) => [newCheckin, ...prev]);
    return reply;
  }, []);

  // Logs
  const logAgentAction = useCallback(
    (agentName: string, actionDescription: string, status: ActionLog['status'] = 'completed') => {
      const newLog: ActionLog = {
        id: `log_${Date.now()}`,
        agentName,
        actionDescription,
        status,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setActionLogs((prev) => [newLog, ...prev]);
    },
    []
  );

  return (
    <AppContext.Provider
      value={{
        profile,
        updateProfile,
        completeOnboarding,
        chats,
        currentChatId,
        messages,
        setMessages,
        notes,
        quizzes,
        mistakes,
        studyPlan,
        checkins,
        actionLogs,
        createNewChat,
        selectChat,
        deleteCurrentChat,
        deleteAllData,
        addNote,
        deleteNote,
        addQuizResult,
        addMistake,
        reviewMistake,
        deleteMistake,
        addPlanTask,
        approvePlanTask,
        rejectPlanTask,
        togglePlanTask,
        deletePlanTask,
        addCheckin,
        logAgentAction,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
