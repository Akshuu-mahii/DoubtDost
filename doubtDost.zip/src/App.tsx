/**
 * Doubt Dost - Main Application Entrypoint
 * Full-screen viewport (100vw x 100dvh).
 * Pure frontend: zero backend, zero Firebase, 100% browser localStorage persistence.
 * Direct Gemini API streaming via @google/genai.
 * Calming teal/purple palette, light & dark mode, never red (soft orange for errors).
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { OnboardingPage } from './pages/OnboardingPage';
import { ActivityStrip } from './components/ActivityStrip';
import { Sidebar, ActiveNavTab } from './components/Sidebar';
import { ChatView } from './views/ChatView';
import { ProgressView } from './views/ProgressView';
import { StudyPlanView } from './views/StudyPlanView';
import { NotesView } from './views/NotesView';
import { CheckinView } from './views/CheckinView';
import { SettingsView } from './views/SettingsView';
import { ActionLogView } from './views/ActionLogView';
import { SourcesPanel } from './components/SourcesPanel';
import { QuizPanel } from './components/QuizPanel';
import { ActivitiesModal } from './components/ActivitiesModal';
import { SafetyInterventionModal } from './components/SafetyInterventionModal';
import {
  ChatMessage,
  AnswerStyle,
  LearningModelType,
  AgentActivityState,
  QuizQuestion,
  UserNote,
  MistakeItem,
  StudyPlanItem,
} from './types';
import {
  streamLessonContent,
  generateQuizDirect,
  verifyLessonDirect,
  generateActivitiesDirect,
  runFastSafetyCheck,
  parseGeminiError,
} from './services/gemini';
import {
  PanelRightClose,
  PanelRightOpen,
  Sparkles,
  ShieldCheck,
  HelpCircle,
  TrendingUp,
  MessageSquare,
  Calendar,
  FileText,
  HeartHandshake,
  Settings,
  X,
  Gauge,
  Activity,
  Award,
} from 'lucide-react';

// Retrieval-Augmented Generation: simple keyword retrieval over local notes
function retrieveTopNoteChunks(notes: UserNote[], queryText: string, maxChunks = 4): string {
  if (!notes || notes.length === 0) return '';
  const queryTerms = queryText
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w.length > 3);

  const allChunks: { text: string; score: number }[] = [];

  for (const note of notes) {
    const chunks = note.chunks && note.chunks.length > 0 ? note.chunks : [note.content];
    for (const chunk of chunks) {
      const lower = chunk.toLowerCase();
      let matchCount = 0;
      for (const term of queryTerms) {
        if (lower.includes(term)) matchCount++;
      }
      allChunks.push({ text: chunk, score: matchCount });
    }
  }

  // Sort by highest match score
  allChunks.sort((a, b) => b.score - a.score);
  const relevant = allChunks.filter((c) => c.score > 0).slice(0, maxChunks);
  if (relevant.length === 0) {
    return allChunks.slice(0, 2).map((c) => c.text).join('\n\n---\n\n');
  }
  return relevant.map((c) => c.text).join('\n\n---\n\n');
}

const MainApp: React.FC = () => {
  const {
    profile,
    messages,
    setMessages,
    notes,
    quizzes,
    addQuizResult,
    addMistake,
    addPlanTask,
    logAgentAction,
    createNewChat,
    currentChatId,
  } = useApp();
  const { theme } = useTheme();

  // Navigation & Layout State
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('chat');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [rightPanelOpen, setRightPanelOpen] = useState<boolean>(false);
  const [rightPanelTab, setRightPanelTab] = useState<'sources' | 'confidence' | 'agents' | 'quiz' | 'activities'>('confidence');

  // Agent Activity Strip State
  const [agentActivity, setAgentActivity] = useState<AgentActivityState>({
    tutor: 'idle',
    truthCheck: 'idle',
    quiz: 'idle',
    planner: 'idle',
    safety: 'active',
  });

  // Streaming State & Abort Controller
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const lastPromptRef = useRef<{
    text: string;
    style: AnswerStyle;
    tryFirst: boolean;
    modelType: LearningModelType;
  } | null>(null);

  // Active right-panel payloads
  const [activeSourceMessage, setActiveSourceMessage] = useState<ChatMessage | null>(null);
  const [activeQuizTopic, setActiveQuizTopic] = useState<string>('Current Lesson');
  const [activeQuizQuestions, setActiveQuizQuestions] = useState<QuizQuestion[]>([]);
  const [activeActivitiesTopic, setActiveActivitiesTopic] = useState<string | null>(null);
  const [distressMessage, setDistressMessage] = useState<string | null>(null);

  // If onboarding is not completed, show Onboarding screen first!
  if (!profile.onboardingComplete) {
    return <OnboardingPage />;
  }

  // Abort streaming
  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
    setAgentActivity((prev) => ({ ...prev, tutor: 'idle' }));
    logAgentAction('Tutor', 'Streaming paused by student.', 'completed');
  };

  // Main streaming handler using @google/genai client-side
  const handleSendMessage = async (
    text: string,
    style: AnswerStyle,
    tryFirst: boolean,
    modelType: LearningModelType = 'gemini-flash'
  ) => {
    if (!text.trim() || isStreaming) return;
    setStreamError(null);
    lastPromptRef.current = { text, style, tryFirst, modelType };

    // 1. Parallel Safety Check
    const safetyResult = runFastSafetyCheck(text);
    if (safetyResult.distressed && safetyResult.warmMessage) {
      setDistressMessage(safetyResult.warmMessage);
      logAgentAction('Safety', 'Distress intervention triggered with supportive helpline resources.');
      return;
    }

    // 2. Note Grounding Retrieval
    const notesContext = retrieveTopNoteChunks(notes, text);
    const initialTruthStatus: ChatMessage['truthCheckStatus'] =
      notes.length > 0 && notesContext.trim().length > 0
        ? 'Partly verified'
        : 'General answer, not from your notes';

    // 3. User Message & Optimistic Assistant Placeholder
    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const assistantMsgId = `msg_a_${Date.now()}`;
    const initialAssistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      style,
      modelType,
      tryFirst,
      streaming: true,
      truthCheckStatus: initialTruthStatus,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg, initialAssistantMsg]);
    setIsStreaming(true);
    setAgentActivity((prev) => ({
      ...prev,
      tutor: 'streaming',
      truthCheck: notes.length > 0 ? 'active' : 'idle',
      quiz: 'pre-generating',
    }));
    logAgentAction('Tutor', `Generating ${style} on "${text.slice(0, 30)}..."`, 'in_progress');

    // 4. Create AbortController
    const controller = new AbortController();
    abortControllerRef.current = controller;

    let streamedAccumulator = '';

    try {
      // Direct client-side streaming via @google/genai
      const finalContent = await streamLessonContent({
        messages: [...messages, userMsg].map((m) => ({ role: m.role, content: m.content })),
        style,
        modelType,
        language: profile.preferredLanguage,
        tryFirst,
        notesContext,
        studentLevel: profile.level,
        studentInterests: profile.interests,
        onChunk: (chunkText) => {
          streamedAccumulator += chunkText;
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantMsgId ? { ...m, content: streamedAccumulator } : m))
          );
        },
        signal: controller.signal,
      });

      // Stream completed successfully! Finalize message
      setIsStreaming(false);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantMsgId
            ? {
                ...m,
                content: finalContent || streamedAccumulator,
                streaming: false,
              }
            : m
        )
      );
      setAgentActivity((prev) => ({ ...prev, tutor: 'idle' }));
      logAgentAction('Tutor', `Delivered complete ${style}.`, 'completed');

      // 5. Background Agents: TruthCheck & Quiz Pre-generation
      const topicForQuiz = text.slice(0, 50).trim();
      setActiveQuizTopic(topicForQuiz);

      // TruthCheck agent in background
      verifyLessonDirect({
        answer: finalContent || streamedAccumulator,
        notesContext,
        topic: topicForQuiz,
      })
        .then((truthResult) => {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsgId
                ? {
                    ...m,
                    truthCheckStatus: truthResult.status,
                    truthCheckSources: truthResult.sources,
                    truthCheckExplanation: truthResult.summary,
                    truthCheckNotesCount: truthResult.notesMatchCount,
                  }
                : m
            )
          );
          setAgentActivity((prev) => ({ ...prev, truthCheck: 'idle' }));
          logAgentAction('TruthCheck', `Verified answer: ${truthResult.status}`, 'completed');
        })
        .catch(() => {
          setAgentActivity((prev) => ({ ...prev, truthCheck: 'idle' }));
        });

      // Quiz agent pre-generation in background
      generateQuizDirect({
        topic: topicForQuiz,
        studentLevel: profile.level,
        language: profile.preferredLanguage,
        notesContext,
      })
        .then((quizQs) => {
          if (quizQs && quizQs.length >= 8) {
            setActiveQuizQuestions(quizQs);
            setMessages((prev) =>
              prev.map((m) => (m.id === assistantMsgId ? { ...m, quizPreGenerated: quizQs } : m))
            );
            setAgentActivity((prev) => ({ ...prev, quiz: 'idle' }));
            logAgentAction('Quiz', `Pre-generated 8 diagnostic questions for "${topicForQuiz}".`, 'completed');
          }
        })
        .catch(() => {
          setAgentActivity((prev) => ({ ...prev, quiz: 'idle' }));
        });
    } catch (err: any) {
      if (err.name === 'AbortError' || err.message?.includes('cancelled')) {
        // User voluntarily stopped
        setIsStreaming(false);
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantMsgId ? { ...m, streaming: false } : m))
        );
        return;
      }

      // If Gemini fails or quota is reached:
      // Show soft orange error message with Retry, stop typing cursor,
      // and DO NOT save the error as an answer!
      console.warn('Gemini streaming error:', err);
      setIsStreaming(false);
      setAgentActivity((prev) => ({ ...prev, tutor: 'idle', truthCheck: 'idle', quiz: 'idle' }));

      // Remove the empty/partially broken assistant message so it is NEVER saved as an answer!
      setMessages((prev) => prev.filter((m) => m.id !== assistantMsgId));

      const friendlyMsg = parseGeminiError(err);
      setStreamError(friendlyMsg);
      logAgentAction('Tutor', `Gemini service pause: ${friendlyMsg}`, 'failed');
    }
  };

  // Retry last failed prompt
  const handleRetry = () => {
    if (lastPromptRef.current) {
      const { text, style, tryFirst, modelType } = lastPromptRef.current;
      handleSendMessage(text, style, tryFirst, modelType);
    }
  };

  // "Purinjudha?" thumbs down: re-explain simply with a different everyday example
  const handleReExplainSimply = (origMsg: ChatMessage) => {
    const prompt = `Can you explain this again much more simply with a different real-life everyday example? Original concept: "${origMsg.content.slice(0, 120)}"`;
    handleSendMessage(prompt, 'Detailed lesson', false, 'story-analogy');
    logAgentAction('Tutor', 'Simplifying explanation with a new relatable analogy.', 'in_progress');
  };

  // Open "Why this answer?" panel
  const handleWhyThisAnswer = (msg: ChatMessage) => {
    setActiveSourceMessage(msg);
    setRightPanelTab('sources');
    setRightPanelOpen(true);
  };

  // Launch Quiz Modal/Panel
  const handleStartQuiz = (topic: string, preGeneratedQuiz?: QuizQuestion[]) => {
    setActiveQuizTopic(topic);
    if (preGeneratedQuiz && preGeneratedQuiz.length >= 8) {
      setActiveQuizQuestions(preGeneratedQuiz);
    }
    setRightPanelTab('quiz');
    setRightPanelOpen(true);
    logAgentAction('Quiz', `Diagnostic quiz started for "${topic}".`, 'in_progress');
  };

  // Open Activities
  const handleOpenActivities = (topic: string) => {
    setActiveActivitiesTopic(topic);
    setRightPanelTab('activities');
    setRightPanelOpen(true);
    logAgentAction('Friend', `Gamified activities opened for "${topic}".`, 'in_progress');
  };

  // Quiz Save Result
  const handleSaveQuizResult = (res: {
    score: number;
    total: number;
    beforeConfidence: number;
    afterConfidence: number;
    strongConcepts: string[];
    weakConcepts: string[];
  }) => {
    addQuizResult({
      topic: activeQuizTopic,
      score: res.score,
      totalQuestions: res.total,
      beforeConfidence: res.beforeConfidence,
      afterConfidence: res.afterConfidence,
      strongConcepts: res.strongConcepts,
      weakConcepts: res.weakConcepts,
    });
    logAgentAction(
      'Quiz',
      `Quiz completed on "${activeQuizTopic}". Score: ${res.score}/${res.total}. Confidence: ${res.beforeConfidence} -> ${res.afterConfidence}.`,
      'completed'
    );
  };

  // Add Weak Concept to Mistake Notebook
  const handleAddMistake = (mistake: Omit<MistakeItem, 'id' | 'date'>) => {
    addMistake(mistake);
    logAgentAction('Tutor', `Logged "${mistake.topic}" to Mistake Notebook.`, 'completed');
  };

  // Suggest Task to Study Planner (requires student Approve / Edit / Reject)
  const handleSuggestPlan = (task: Omit<StudyPlanItem, 'id' | 'createdAt'>) => {
    addPlanTask(task);
    logAgentAction(
      'Planner',
      `Suggested revision task: "${task.task}". Awaiting student approval.`,
      'pending'
    );
  };

  // Overall Confidence average calculation for Confidence Meter
  const latestQuiz = quizzes[0];
  const avgAfterConfidence =
    quizzes.length > 0
      ? (quizzes.reduce((acc, q) => acc + q.afterConfidence, 0) / quizzes.length).toFixed(1)
      : null;

  return (
    <div className="w-[100vw] h-[100dvh] flex flex-col overflow-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-teal-500/30">
      {/* 1. Autonomous Agent Activity Strip (Tutor, TruthCheck, Quiz, Planner, Friend, Safety) */}
      <header className="shrink-0 flex items-center justify-between border-b border-slate-200/80 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md z-20">
        <div className="flex-1 min-w-0">
          <ActivityStrip
            activity={agentActivity}
            activeTopic={activeQuizTopic}
            onOpenAgentDetails={(agentId) => {
              setRightPanelTab('agents');
              setRightPanelOpen(true);
            }}
          />
        </div>

        {/* Right Collapsible Panel Toggle Button */}
        <div className="px-3 shrink-0 flex items-center gap-1.5 border-l border-slate-200 dark:border-slate-800">
          <button
            onClick={() => {
              setRightPanelOpen(!rightPanelOpen);
              if (!rightPanelOpen && rightPanelTab === 'sources' && !activeSourceMessage) {
                setRightPanelTab('confidence');
              }
            }}
            title={rightPanelOpen ? 'Collapse side panel' : 'Expand agent & confidence panel'}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            {rightPanelOpen ? (
              <>
                <PanelRightClose className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span className="hidden sm:inline">Hide Panel</span>
              </>
            ) : (
              <>
                <PanelRightOpen className="w-4 h-4" />
                <span className="hidden sm:inline">Agents & Mastery</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* 2. Main Viewport Row: Left Sidebar + Center Content + Right Collapsible Panel */}
      <div className="flex-1 flex overflow-hidden min-h-0 relative">
        {/* Left Sidebar (Desktop / Tablet) */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            if (window.innerWidth < 768) {
              setRightPanelOpen(false);
            }
          }}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* Center Main Stage */}
        <main className="flex-1 flex flex-col min-h-0 min-w-0 bg-transparent overflow-hidden relative">
          {activeTab === 'chat' && (
            <ChatView
              onSendMessage={handleSendMessage}
              onStopStreaming={handleStopStreaming}
              isStreaming={isStreaming}
              streamError={streamError}
              onRetry={handleRetry}
              onWhyThisAnswer={handleWhyThisAnswer}
              onStartQuiz={(topic, preQs) => handleStartQuiz(topic, preQs)}
              onFeedback={(msgId, fb) => {
                setMessages((prev) =>
                  prev.map((m) => (m.id === msgId ? { ...m, feedback: fb } : m))
                );
                logAgentAction('Tutor', `Student marked answer feedback: ${fb}.`, 'completed');
              }}
              onReExplainSimply={handleReExplainSimply}
            />
          )}

          {activeTab === 'progress' && <ProgressView />}
          {activeTab === 'study_plan' && <StudyPlanView />}
          {activeTab === 'notes' && <NotesView />}
          {activeTab === 'checkin' && (
            <CheckinView onDistressDetected={(msg) => setDistressMessage(msg)} />
          )}
          {activeTab === 'action_log' && <ActionLogView />}
          {activeTab === 'settings' && <SettingsView />}
        </main>

        {/* Right Collapsible Panel (Desktop side, Mobile/Tablet drawer) */}
        {rightPanelOpen && (
          <aside className="w-full sm:w-88 md:w-96 h-full min-h-0 z-40 bg-white dark:bg-slate-900 border-l border-slate-200/80 dark:border-slate-800 shadow-xl flex flex-col absolute md:relative right-0 top-0 transition-all duration-300">
            {/* Right Panel Sub-navigation */}
            <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/60 shrink-0">
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar text-xs">
                <button
                  onClick={() => setRightPanelTab('confidence')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                    rightPanelTab === 'confidence'
                      ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <Gauge className="w-3.5 h-3.5" />
                  Mastery
                </button>
                <button
                  onClick={() => setRightPanelTab('agents')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                    rightPanelTab === 'agents'
                      ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  Agents
                </button>
                {activeSourceMessage && (
                  <button
                    onClick={() => setRightPanelTab('sources')}
                    className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                      rightPanelTab === 'sources'
                        ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Sources
                  </button>
                )}
                {activeQuizQuestions.length > 0 && (
                  <button
                    onClick={() => setRightPanelTab('quiz')}
                    className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                      rightPanelTab === 'quiz'
                        ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    Quiz ({activeQuizQuestions.length})
                  </button>
                )}
              </div>

              <button
                onClick={() => setRightPanelOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition cursor-pointer"
                title="Close panel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Right Panel Body */}
            <div className="flex-1 overflow-y-auto min-h-0 relative">
              {/* Tab 1: Sources / Grounding ("Why this answer?") */}
              {rightPanelTab === 'sources' && (
                <SourcesPanel
                  status={activeSourceMessage?.truthCheckStatus || 'General answer, not from your notes'}
                  sources={activeSourceMessage?.truthCheckSources || []}
                  explanation={activeSourceMessage?.truthCheckExplanation}
                  answerContent={activeSourceMessage?.content}
                  notesContent={notes[0]?.content}
                  onClose={() => setRightPanelTab('confidence')}
                  onUploadNotesPrompt={() => {
                    setRightPanelOpen(false);
                    setActiveTab('notes');
                  }}
                />
              )}

              {/* Tab 2: Confidence & Mastery Meter */}
              {rightPanelTab === 'confidence' && (
                <div className="p-5 space-y-6 text-sm">
                  <div>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                      <Gauge className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      Confidence & Mastery Meter
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Tracking your self-rated understanding before and after diagnostic quizzes.
                    </p>
                  </div>

                  {quizzes.length === 0 ? (
                    <div className="p-6 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-3 bg-slate-50/50 dark:bg-slate-850/50">
                      <div className="w-10 h-10 mx-auto rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                        <Award className="w-5 h-5" />
                      </div>
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        No quiz results yet!
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Complete your first lesson and take an 8-question quiz to see your confidence progression here.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Overall stats */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-center">
                          <span className="text-[11px] font-semibold text-teal-700 dark:text-teal-300 block">
                            Avg Mastery Rating
                          </span>
                          <span className="text-2xl font-black text-teal-600 dark:text-teal-400 mt-0.5 block">
                            {avgAfterConfidence} / 5
                          </span>
                        </div>
                        <div className="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-center">
                          <span className="text-[11px] font-semibold text-indigo-700 dark:text-indigo-300 block">
                            Quizzes Completed
                          </span>
                          <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-0.5 block">
                            {quizzes.length}
                          </span>
                        </div>
                      </div>

                      {/* Latest quiz before vs after card */}
                      {latestQuiz && (
                        <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-3">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-slate-900 dark:text-white truncate max-w-[180px]">
                              {latestQuiz.topic}
                            </span>
                            <span className="text-teal-600 dark:text-teal-400 font-bold">
                              {latestQuiz.score} / {latestQuiz.totalQuestions}
                            </span>
                          </div>

                          <div className="space-y-1.5">
                            <div className="flex justify-between text-xs text-slate-500">
                              <span>Before Lesson: {latestQuiz.beforeConfidence}/5</span>
                              <span>After Lesson: {latestQuiz.afterConfidence}/5</span>
                            </div>
                            <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
                              <div
                                style={{ width: `${(latestQuiz.beforeConfidence / 5) * 100}%` }}
                                className="bg-slate-400 dark:bg-slate-600 h-full"
                              />
                              <div
                                style={{
                                  width: `${
                                    Math.max(
                                      0,
                                      (latestQuiz.afterConfidence - latestQuiz.beforeConfidence) / 5
                                    ) * 100
                                  }%`,
                                }}
                                className="bg-teal-500 h-full"
                              />
                            </div>
                          </div>

                          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
                            <span>Confidence Growth:</span>
                            <span className="font-bold text-teal-600 dark:text-teal-400">
                              +{Math.max(0, latestQuiz.afterConfidence - latestQuiz.beforeConfidence)} Star(s)
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Notes Grounding Summary */}
                  <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-850/60 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                      <FileText className="w-3.5 h-3.5 text-teal-600" />
                      <span>Syllabus Notes Grounding</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {notes.length === 0
                        ? 'No textbook notes uploaded yet. Lessons will provide general curriculum answers.'
                        : `${notes.length} note document(s) uploaded. Every answer is cross-checked against your syllabus.`}
                    </p>
                    {notes.length === 0 && (
                      <button
                        onClick={() => {
                          setRightPanelOpen(false);
                          setActiveTab('notes');
                        }}
                        className="text-xs font-semibold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                      >
                        Upload textbook PDF or text →
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Tab 3: Autonomous Agent Activity Monitor */}
              {rightPanelTab === 'agents' && (
                <div className="p-5 space-y-5 text-sm">
                  <div>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      Active Agents Monitor
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      DoubtDost orchestrates 6 collaborative AI agents under your direct supervision.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {/* Tutor */}
                    <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-teal-700 dark:text-teal-400 text-xs">Tutor Agent</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                            agentActivity.tutor === 'streaming'
                              ? 'bg-teal-500/15 text-teal-600 animate-pulse'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                          }`}
                        >
                          {agentActivity.tutor === 'streaming' ? 'Streaming' : 'Ready'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        Delivers structured 8-step lessons, works through examples, and aligns answers to your syllabus.
                      </p>
                    </div>

                    {/* TruthCheck */}
                    <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-700 dark:text-emerald-400 text-xs">TruthCheck Agent</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                            agentActivity.truthCheck === 'active'
                              ? 'bg-emerald-500/15 text-emerald-600 animate-pulse'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                          }`}
                        >
                          {agentActivity.truthCheck === 'active' ? 'Verifying' : 'Idle'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        Cross-checks generated answers against your uploaded notes and textbook extracts to eliminate hallucinations.
                      </p>
                    </div>

                    {/* Quiz */}
                    <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-700 dark:text-amber-400 text-xs">Quiz Agent</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                            agentActivity.quiz === 'pre-generating'
                              ? 'bg-amber-500/15 text-amber-600 animate-pulse'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                          }`}
                        >
                          {agentActivity.quiz === 'pre-generating' ? 'Pre-generating' : 'Ready'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        Pre-generates 8-question rising difficulty diagnostics with immediate kind feedback (never red).
                      </p>
                    </div>

                    {/* Planner */}
                    <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-indigo-700 dark:text-indigo-400 text-xs">Planner Agent</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-slate-100 dark:bg-slate-800 text-slate-500">
                          Student-Supervised
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        Identifies weak concepts and drafts revision tasks. Requires your explicit Approve, Edit, or Reject.
                      </p>
                    </div>

                    {/* Friend */}
                    <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-rose-700 dark:text-rose-400 text-xs">Friend Agent</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-rose-500/10 text-rose-600">
                          Active
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        Daily emotional check-ins, mood emoji tracking, and encouraging conversational replies.
                      </p>
                    </div>

                    {/* Safety */}
                    <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-purple-700 dark:text-purple-400 text-xs">Safety Agent</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-purple-500/10 text-purple-600">
                          Continuous
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        Runs in parallel with every prompt to protect wellbeing and provide immediate crisis helplines if needed.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Diagnostic Quiz Panel */}
              {rightPanelTab === 'quiz' && (
                <QuizPanel
                  topic={activeQuizTopic}
                  questions={activeQuizQuestions}
                  onClose={() => setRightPanelTab('confidence')}
                  onSaveResult={handleSaveQuizResult}
                  onAddMistake={handleAddMistake}
                  onSuggestPlan={handleSuggestPlan}
                  interests={profile.interests}
                  onOpenActivities={handleOpenActivities}
                />
              )}

              {/* Tab 5: Gamified Learning Activities */}
              {rightPanelTab === 'activities' && (
                <ActivitiesModal
                  topic={activeActivitiesTopic || activeQuizTopic}
                  interests={profile.interests}
                  onClose={() => setRightPanelTab('confidence')}
                />
              )}
            </div>
          </aside>
        )}
      </div>

      {/* Safety Distress Intervention Modal (Soft amber, warm, non-judgmental) */}
      {distressMessage && (
        <SafetyInterventionModal
          warmMessage={distressMessage}
          trustedContact={profile.trustedContact}
          onClose={() => setDistressMessage(null)}
        />
      )}

      {/* Mobile Bottom Tab Bar (full screen navigation on phones) */}
      <nav className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-2 py-1.5 flex items-center justify-around text-xs shrink-0 z-20">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex flex-col items-center py-1 px-2 transition ${
            activeTab === 'chat'
              ? 'text-teal-600 dark:text-teal-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Chat</span>
        </button>

        <button
          onClick={() => setActiveTab('progress')}
          className={`flex flex-col items-center py-1 px-2 transition ${
            activeTab === 'progress'
              ? 'text-teal-600 dark:text-teal-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Progress</span>
        </button>

        <button
          onClick={() => setActiveTab('study_plan')}
          className={`flex flex-col items-center py-1 px-2 transition ${
            activeTab === 'study_plan'
              ? 'text-teal-600 dark:text-teal-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Plan</span>
        </button>

        <button
          onClick={() => setActiveTab('notes')}
          className={`flex flex-col items-center py-1 px-2 transition ${
            activeTab === 'notes'
              ? 'text-teal-600 dark:text-teal-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Notes</span>
        </button>

        <button
          onClick={() => setActiveTab('checkin')}
          className={`flex flex-col items-center py-1 px-2 transition ${
            activeTab === 'checkin'
              ? 'text-teal-600 dark:text-teal-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <HeartHandshake className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Friend</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center py-1 px-2 transition ${
            activeTab === 'settings'
              ? 'text-teal-600 dark:text-teal-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Settings</span>
        </button>
      </nav>
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <MainApp />
      </AppProvider>
    </ThemeProvider>
  );
}
