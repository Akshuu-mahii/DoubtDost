/**
 * Nanban AI - Grounding & TruthCheck Panel ("Why this answer?")
 * Explains how claims were verified, lists note sections or curriculum references,
 * highlights unsupported claims (if any), and provides a side-by-side comparison mode.
 */

import React, { useState } from 'react';
import { X, ShieldCheck, AlertTriangle, FileText, CheckCircle2, SplitSquareVertical } from 'lucide-react';

interface SourcesPanelProps {
  status: 'Verified' | 'Partly verified' | 'Not verified' | 'General answer, not from your notes';
  sources?: string[];
  notesMatchCount?: number;
  explanation?: string;
  answerContent?: string;
  notesContent?: string;
  onClose: () => void;
  onUploadNotesPrompt?: () => void;
}

export const SourcesPanel: React.FC<SourcesPanelProps> = ({
  status,
  sources = [],
  notesMatchCount = 0,
  explanation,
  answerContent = '',
  notesContent = '',
  onClose,
  onUploadNotesPrompt,
}) => {
  const [showComparison, setShowComparison] = useState<boolean>(false);

  const getStatusBadge = () => {
    switch (status) {
      case 'Verified':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Verified with Student Notes
          </span>
        );
      case 'Partly verified':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            Partly Verified
          </span>
        );
      case 'Not verified':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-orange-500/15 text-orange-700 dark:text-orange-300 border border-orange-500/30 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            Not Verified in Notes
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-500/15 text-slate-700 dark:text-slate-300 border border-slate-500/30 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" />
            General answer, not from your notes
          </span>
        );
    }
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40 sticky top-0 z-10 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <h3 className="font-semibold text-sm text-slate-900 dark:text-white">Why this answer?</h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 md:p-5 flex-1 space-y-5">
        {/* Verification Status */}
        <div>
          <div className="mb-2">{getStatusBadge()}</div>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            {explanation ||
              (status === 'General answer, not from your notes'
                ? "You haven't uploaded notes for this topic yet. This answer is generated from curriculum-aligned knowledge."
                : 'TruthCheck verified key claims and formulas against your uploaded notes database.')}
          </p>
        </div>

        {/* Sources or Notes Chunks List */}
        <div className="space-y-2.5">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Grounding Sources & References
          </h4>
          {sources && sources.length > 0 ? (
            <div className="space-y-2">
              {sources.map((src, i) => (
                <div
                  key={i}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 flex items-start gap-2"
                >
                  <FileText className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{src}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
              No specific note chunk linked.
            </div>
          )}
        </div>

        {/* Upload Notes CTA if no notes */}
        {status === 'General answer, not from your notes' && onUploadNotesPrompt && (
          <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/50 space-y-2">
            <h5 className="font-semibold text-xs text-teal-900 dark:text-teal-200">
              Want syllabus-accurate answers?
            </h5>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Upload your school/college textbook notes or syllabus PDFs. TruthCheck will verify every lesson against
              your exact teacher notes!
            </p>
            <button
              onClick={onUploadNotesPrompt}
              className="mt-1 w-full py-2 px-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-xs transition cursor-pointer"
            >
              Upload Notes & Syllabus
            </button>
          </div>
        )}

        {/* Compare Button */}
        {notesContent && (
          <div>
            <button
              onClick={() => setShowComparison(!showComparison)}
              className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <SplitSquareVertical className="w-4 h-4 text-indigo-500" />
              <span>{showComparison ? 'Hide Side-by-Side Comparison' : 'Compare General vs Notes-Based Answer'}</span>
            </button>

            {showComparison && (
              <div className="mt-3 grid grid-cols-1 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Your Uploaded Note Snippet:
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 max-h-36 overflow-y-auto leading-relaxed">
                    {notesContent}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200 dark:border-teal-800">
                  <span className="font-bold text-teal-800 dark:text-teal-200 block mb-1">
                    Nanban AI Synthesized Lesson:
                  </span>
                  <p className="text-slate-700 dark:text-slate-300 max-h-36 overflow-y-auto leading-relaxed">
                    {answerContent.slice(0, 400)}...
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
