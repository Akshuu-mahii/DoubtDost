/**
 * Nanban AI - Interactive Gamified Learning Activities
 * Scenario puzzles, analogy cards, story mode, match-the-pairs game,
 * flashcards, meme/caption challenge, and mini projects.
 */

import React, { useState, useEffect } from 'react';
import { X, Sparkles, CheckCircle2, RotateCcw, Puzzle, BookMarked, Gamepad2, Layers } from 'lucide-react';

interface ActivityItem {
  id: string;
  type: string;
  title: string;
  description: string;
  task?: string;
  pairs?: { left: string; right: string }[];
}

interface ActivitiesModalProps {
  topic: string;
  interests?: string[];
  onClose: () => void;
}

export const ActivitiesModal: React.FC<ActivitiesModalProps> = ({ topic, interests = [], onClose }) => {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<number>(0);

  // Match the pairs game state
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [selectedRight, setSelectedRight] = useState<string | null>(null);
  const [matchNotice, setMatchNotice] = useState<string | null>(null);

  // Flashcard flip state
  const [flashcardFlipped, setFlashcardFlipped] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    const fetchActivities = async () => {
      setLoading(true);
      try {
        const res = await fetch('/api/activities/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ topic, interests }),
        });
        if (res.ok) {
          const data = await res.json();
          if (isMounted && data.activities) {
            setActivities(data.activities);
          }
        }
      } catch (err) {
        console.error('[Nanban AI] Activities fetch error:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchActivities();
    return () => {
      isMounted = false;
    };
  }, [topic, interests]);

  const currentActivity = activities[activeTab];

  const handlePairMatch = (left: string, right: string, pairs: { left: string; right: string }[]) => {
    const isMatch = pairs.some((p) => p.left === left && p.right === right);
    if (isMatch) {
      setMatchedPairs((prev) => [...prev, left]);
      setMatchNotice('✓ Perfect match!');
      setSelectedLeft(null);
      setSelectedRight(null);
    } else {
      setMatchNotice('Not a match, try again!');
      setTimeout(() => {
        setSelectedLeft(null);
        setSelectedRight(null);
        setMatchNotice(null);
      }, 1000);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40 sticky top-0 z-10 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Gamepad2 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-sm text-slate-900 dark:text-white">Topic Activities</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">{topic}</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 md:p-5 flex-1 flex flex-col justify-between space-y-4">
        {loading ? (
          <div className="my-auto text-center py-10 space-y-3">
            <div className="w-8 h-8 mx-auto border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs text-slate-500">Creating custom games & analogies...</p>
          </div>
        ) : activities.length > 0 && currentActivity ? (
          <div className="space-y-4">
            {/* Activity Category Tabs */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {activities.map((act, i) => (
                <button
                  key={act.id || i}
                  onClick={() => {
                    setActiveTab(i);
                    setSelectedLeft(null);
                    setSelectedRight(null);
                    setMatchNotice(null);
                    setFlashcardFlipped(false);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer border ${
                    activeTab === i
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm shadow-indigo-500/20'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {act.type}
                </button>
              ))}
            </div>

            {/* Active Activity Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/50 to-purple-50/30 dark:from-slate-800/60 dark:to-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                  {currentActivity.type}
                </span>
                <Sparkles className="w-4 h-4 text-amber-500" />
              </div>
              <h4 className="font-bold text-base text-slate-900 dark:text-white">{currentActivity.title}</h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {currentActivity.description}
              </p>

              {/* Task Content */}
              {currentActivity.task && (
                <div className="mt-3 p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs md:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                  {currentActivity.task}
                </div>
              )}

              {/* Match the Pairs Game Mode */}
              {currentActivity.pairs && currentActivity.pairs.length > 0 && (
                <div className="mt-4 space-y-3">
                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Match each concept with its correct partner:
                  </div>

                  {matchNotice && (
                    <div className="p-2 text-center text-xs font-medium text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40 rounded-lg">
                      {matchNotice}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {/* Left Items */}
                    <div className="space-y-1.5">
                      {currentActivity.pairs.map((p, idx) => {
                        const matched = matchedPairs.includes(p.left);
                        const isSelected = selectedLeft === p.left;
                        return (
                          <button
                            key={`left-${idx}`}
                            disabled={matched}
                            onClick={() => {
                              setSelectedLeft(p.left);
                              if (selectedRight) {
                                handlePairMatch(p.left, selectedRight, currentActivity.pairs || []);
                              }
                            }}
                            className={`w-full p-2.5 rounded-xl text-left font-medium transition cursor-pointer border ${
                              matched
                                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300 opacity-60'
                                : isSelected
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 hover:border-indigo-400'
                            }`}
                          >
                            {p.left} {matched && '✓'}
                          </button>
                        );
                      })}
                    </div>

                    {/* Right Items */}
                    <div className="space-y-1.5">
                      {currentActivity.pairs.map((p, idx) => {
                        const matched = matchedPairs.some((left) =>
                          currentActivity.pairs?.some((pr) => pr.left === left && pr.right === p.right)
                        );
                        const isSelected = selectedRight === p.right;
                        return (
                          <button
                            key={`right-${idx}`}
                            disabled={matched}
                            onClick={() => {
                              setSelectedRight(p.right);
                              if (selectedLeft) {
                                handlePairMatch(selectedLeft, p.right, currentActivity.pairs || []);
                              }
                            }}
                            className={`w-full p-2.5 rounded-xl text-left font-medium transition cursor-pointer border ${
                              matched
                                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300 opacity-60'
                                : isSelected
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 hover:border-indigo-400'
                            }`}
                          >
                            {p.right} {matched && '✓'}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-xs text-slate-400">
            No activities generated. Please try again.
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white font-medium text-xs hover:bg-slate-800 transition cursor-pointer"
        >
          Close Activities
        </button>
      </div>
    </div>
  );
};
