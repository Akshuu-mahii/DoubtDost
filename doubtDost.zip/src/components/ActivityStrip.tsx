/**
 * Doubt Dost - Agent Activity Strip
 * Displays real-time status for the 6 core agents:
 * Tutor, TruthCheck, Quiz, Planner, Friend, Safety.
 */

import React from 'react';
import { BookOpen, ShieldCheck, HelpCircle, Calendar, Heart, ShieldAlert } from 'lucide-react';
import { AgentActivityState } from '../types';

interface ActivityStripProps {
  activity: AgentActivityState;
  activeTopic?: string;
  onOpenAgentDetails?: (agent: string) => void;
}

export const ActivityStrip: React.FC<ActivityStripProps> = ({
  activity,
  activeTopic,
  onOpenAgentDetails,
}) => {
  const agents = [
    {
      id: 'tutor',
      name: 'Tutor',
      icon: BookOpen,
      status: activity.tutor,
      activeColor: 'text-teal-600 dark:text-teal-400 bg-teal-500/10 border-teal-500/30',
      activeText: activity.tutor === 'streaming' ? 'Streaming lesson...' : 'Ready',
    },
    {
      id: 'truthCheck',
      name: 'TruthCheck',
      icon: ShieldCheck,
      status: activity.truthCheck,
      activeColor: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
      activeText: activity.truthCheck === 'active' ? 'Verifying notes...' : 'Verified',
    },
    {
      id: 'quiz',
      name: 'Quiz',
      icon: HelpCircle,
      status: activity.quiz,
      activeColor: 'text-amber-600 dark:text-amber-400 bg-amber-500/10 border-amber-500/30',
      activeText: activity.quiz === 'pre-generating' ? 'Pre-generating...' : 'Quiz ready',
    },
    {
      id: 'planner',
      name: 'Planner',
      icon: Calendar,
      status: activity.planner,
      activeColor: 'text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
      activeText: activity.planner === 'active' ? 'Updating plan...' : 'Standing by',
    },
    {
      id: 'friend',
      name: 'Friend',
      icon: Heart,
      status: 'idle',
      activeColor: 'text-rose-600 dark:text-rose-400 bg-rose-500/10 border-rose-500/30',
      activeText: 'Ready to listen',
    },
    {
      id: 'safety',
      name: 'Safety',
      icon: ShieldAlert,
      status: activity.safety,
      activeColor: 'text-purple-600 dark:text-purple-400 bg-purple-500/10 border-purple-500/30',
      activeText: 'Parallel safety active',
    },
  ];

  return (
    <div className="w-full bg-white/70 dark:bg-slate-900/70 border-b border-slate-200/80 dark:border-slate-800/80 px-4 py-2 flex items-center justify-between gap-3 text-xs overflow-x-auto no-scrollbar backdrop-blur-sm">
      <div className="flex items-center gap-2 shrink-0">
        <span className="font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
          Agents
        </span>
        {activeTopic && (
          <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px] truncate max-w-[140px]">
            {activeTopic}
          </span>
        )}
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {agents.map((ag) => {
          const Icon = ag.icon;
          const isActive =
            ag.status === 'active' ||
            ag.status === 'streaming' ||
            ag.status === 'pre-generating';
          return (
            <button
              key={ag.id}
              onClick={() => onOpenAgentDetails?.(ag.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border transition cursor-pointer ${
                isActive
                  ? ag.activeColor
                  : 'border-slate-200/60 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
              }`}
            >
              <Icon className={`w-3 h-3 ${isActive ? 'animate-pulse' : ''}`} />
              <span className="font-medium text-[11px]">{ag.name}</span>
              {isActive && <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />}
            </button>
          );
        })}
      </div>
    </div>
  );
};
