/**
 * Nanban AI - Scrolling Model Type Selector
 * Horizontally scrollable carousel/pill bar allowing students to select
 * different AI models & pedagogical archetypes.
 */

import React, { useRef, useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Brain,
  Lightbulb,
  Target,
  Languages,
  Palette,
  Zap,
  Check,
} from 'lucide-react';
import { LearningModelType, ModelTypeOption } from '../types';

export const MODEL_OPTIONS: ModelTypeOption[] = [
  {
    id: 'gemini-flash',
    name: 'Gemini 3.8 Flash',
    badge: 'Default',
    icon: '⚡',
    tagline: 'Balanced & lightning fast',
    description: 'High-speed comprehensive tutor for general lessons and conceptual answers.',
    speed: 'Ultra Fast',
    bestFor: 'General daily study & homework doubts',
  },
  {
    id: 'deep-reasoning',
    name: 'Deep Reasoning Model',
    badge: 'Analytical',
    icon: '🧠',
    tagline: 'Multi-step proofs & derivations',
    description: 'Breaks down tough calculus, physics derivations, and logical proofs step-by-step.',
    speed: 'Deep Think',
    bestFor: 'Maths, Physics, & Engineering derivations',
  },
  {
    id: 'socratic-tutor',
    name: 'Socratic Tutor Model',
    badge: 'Interactive',
    icon: '💡',
    tagline: 'Guides with thoughtful questions',
    description: 'Never just gives the answer away; asks guiding questions to build deep intuition.',
    speed: 'Fast',
    bestFor: 'Active recall & building problem intuition',
  },
  {
    id: 'exam-specialist',
    name: 'Exam Specialist Model',
    badge: 'Board & NEET/JEE',
    icon: '🎯',
    tagline: 'Strict marking scheme alignment',
    description: 'Formats answers with key technical buzzwords, point distribution, and exam tips.',
    speed: 'Fast',
    bestFor: 'Class 10/12 Board Exams, NEET & JEE',
  },
  {
    id: 'tanglish-bilingual',
    name: 'Tanglish & Bilingual',
    badge: 'Tamil + English',
    icon: '🗣️',
    tagline: 'Comfortable colloquial Tamil blend',
    description: 'Explains complex concepts in a friendly Tamil-English dialect that feels like a friend tutoring you.',
    speed: 'Ultra Fast',
    bestFor: 'Tamil Nadu state board & conversational clarity',
  },
  {
    id: 'story-analogy',
    name: 'Story & Analogy Model',
    badge: 'Creative',
    icon: '🎨',
    tagline: 'Tied to Cricket, Anime, Movies',
    description: 'Explains every concept using creative metaphors from your saved interests and hobbies.',
    speed: 'Fast',
    bestFor: 'Visual thinkers & making dry topics memorable',
  },
  {
    id: 'quick-doubt',
    name: 'Quick Doubt Solver',
    badge: 'Rapid',
    icon: '🚀',
    tagline: '30-second bulleted answers',
    description: 'Bypasses lengthy intros; delivers the exact formula, definition, or answer immediately.',
    speed: 'Ultra Fast',
    bestFor: 'Last-minute exam revision & quick fact checks',
  },
];

interface ScrollingModelSelectorProps {
  selectedModel: LearningModelType;
  onSelectModel: (model: LearningModelType) => void;
  compact?: boolean;
}

export const ScrollingModelSelector: React.FC<ScrollingModelSelectorProps> = ({
  selectedModel,
  onSelectModel,
  compact = false,
}) => {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [canScrollLeft, setCanScrollLeft] = useState<boolean>(false);
  const [canScrollRight, setCanScrollRight] = useState<boolean>(true);

  const checkScrollability = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 10);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  useEffect(() => {
    checkScrollability();
    window.addEventListener('resize', checkScrollability);
    return () => window.removeEventListener('resize', checkScrollability);
  }, []);

  const handleScroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const scrollAmount = 240;
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
    setTimeout(checkScrollability, 300);
  };

  const activeModelOption = MODEL_OPTIONS.find((m) => m.id === selectedModel) || MODEL_OPTIONS[0];

  return (
    <div className="w-full relative group">
      {/* Scroll Navigation Header & Active Label */}
      <div className="flex items-center justify-between px-1 mb-1.5 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            AI Model Type:
          </span>
          <span className="font-semibold text-teal-700 dark:text-teal-300 flex items-center gap-1 text-[11px]">
            <span>{activeModelOption.icon}</span>
            <span>{activeModelOption.name}</span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400">
              {activeModelOption.badge}
            </span>
          </span>
        </div>

        {/* Scroll Arrows */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => handleScroll('left')}
            disabled={!canScrollLeft}
            aria-label="Scroll models left"
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => handleScroll('right')}
            disabled={!canScrollRight}
            aria-label="Scroll models right"
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Horizontal Scrolling Model Cards Container */}
      <div
        ref={scrollRef}
        onScroll={checkScrollability}
        className="flex items-stretch gap-2 overflow-x-auto py-1 px-0.5 no-scrollbar scroll-smooth"
      >
        {MODEL_OPTIONS.map((opt) => {
          const isSelected = selectedModel === opt.id;
          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => onSelectModel(opt.id)}
              className={`flex-shrink-0 text-left p-2.5 rounded-2xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                compact ? 'w-44' : 'w-52 md:w-56'
              } ${
                isSelected
                  ? 'border-teal-500 bg-teal-500/10 dark:bg-teal-500/15 shadow-sm ring-1 ring-teal-500/30'
                  : 'border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-850/60 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-white dark:hover:bg-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">{opt.icon}</span>
                    <span
                      className={`font-bold text-xs truncate ${
                        isSelected ? 'text-teal-900 dark:text-teal-100' : 'text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      {opt.name}
                    </span>
                  </div>
                  {isSelected && (
                    <div className="w-4 h-4 rounded-full bg-teal-600 text-white flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>

                <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 font-medium">
                  {opt.tagline}
                </p>
              </div>

              <div className="mt-2 pt-1.5 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-[9px] text-slate-400">
                <span className="truncate max-w-[120px]">{opt.bestFor}</span>
                <span
                  className={`px-1 py-0.2 rounded font-semibold shrink-0 ${
                    opt.speed === 'Ultra Fast'
                      ? 'text-teal-600 bg-teal-500/10'
                      : opt.speed === 'Deep Think'
                      ? 'text-indigo-600 bg-indigo-500/10'
                      : 'text-amber-600 bg-amber-500/10'
                  }`}
                >
                  {opt.speed}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
