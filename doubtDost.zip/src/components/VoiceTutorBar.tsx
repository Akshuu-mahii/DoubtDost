/**
 * Nanban AI - VoiceTutor Audio Bar
 * Transforms lessons into audio with transcript, replay, speed control,
 * and buttons: "Explain slowly", "Give an example", "Ask me a quiz".
 */

import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, RotateCcw, X, HelpCircle, FastForward } from 'lucide-react';

interface VoiceTutorBarProps {
  text: string;
  topic?: string;
  onClose: () => void;
  onExplainSlowly?: () => void;
  onGiveExample?: () => void;
  onAskQuiz?: () => void;
}

export const VoiceTutorBar: React.FC<VoiceTutorBarProps> = ({
  text,
  topic,
  onClose,
  onExplainSlowly,
  onGiveExample,
  onAskQuiz,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speed, setSpeed] = useState<number>(1);
  const [showTranscript, setShowTranscript] = useState<boolean>(false);

  // Clean text for speech (strip markdown headers, asterisks, tables)
  const cleanSpeechText = text
    .replace(/###\s+/g, '')
    .replace(/\*\*/g, '')
    .replace(/\|/g, ' ')
    .replace(/---/g, '')
    .slice(0, 3000);

  const speak = (rate = speed) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
    utterance.rate = rate;
    utterance.onend = () => setIsPlaying(false);
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  useEffect(() => {
    speak(speed);
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [speed]);

  const togglePlay = () => {
    if (!('speechSynthesis' in window)) return;
    if (isPlaying) {
      window.speechSynthesis.pause();
      setIsPlaying(false);
    } else {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      } else {
        speak(speed);
      }
      setIsPlaying(true);
    }
  };

  const restart = () => {
    speak(speed);
  };

  const cycleSpeed = () => {
    const speeds = [0.75, 1, 1.25, 1.5];
    const nextIdx = (speeds.indexOf(speed) + 1) % speeds.length;
    setSpeed(speeds[nextIdx]);
  };

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 p-3 shadow-lg z-30 flex flex-col gap-2">
      <div className="flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center">
            <Volume2 className="w-3.5 h-3.5 animate-pulse" />
          </div>
          <div>
            <span className="font-semibold text-slate-800 dark:text-slate-200">VoiceTutor</span>
            {topic && <span className="text-slate-500 dark:text-slate-400 ml-1.5">• {topic}</span>}
          </div>
        </div>

        {/* Player controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={restart}
            title="Replay"
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={togglePlay}
            className="p-1.5 px-3 rounded-lg bg-sky-600 text-white font-medium hover:bg-sky-500 transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isPlaying ? 'Pause' : 'Play'}</span>
          </button>
          <button
            onClick={cycleSpeed}
            className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            {speed}x
          </button>
          <button
            onClick={() => setShowTranscript(!showTranscript)}
            className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer border ${
              showTranscript
                ? 'bg-sky-500/20 text-sky-700 dark:text-sky-300 border-sky-500/30'
                : 'border-slate-200 dark:border-slate-800 text-slate-500'
            }`}
          >
            Transcript
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 dark:border-slate-800/60 text-[11px]">
        {onExplainSlowly && (
          <button
            onClick={() => {
              setSpeed(0.75);
              onExplainSlowly();
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-750 transition cursor-pointer"
          >
            Explain slowly
          </button>
        )}
        {onGiveExample && (
          <button
            onClick={onGiveExample}
            className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-750 transition cursor-pointer"
          >
            Give an example
          </button>
        )}
        {onAskQuiz && (
          <button
            onClick={onAskQuiz}
            className="px-2.5 py-1 rounded-lg bg-teal-500/15 text-teal-700 dark:text-teal-300 hover:bg-teal-500/25 transition cursor-pointer flex items-center gap-1 font-medium"
          >
            <HelpCircle className="w-3 h-3" />
            Ask me a quiz
          </button>
        )}
      </div>

      {/* Transcript expandable */}
      {showTranscript && (
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 max-h-32 overflow-y-auto text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          {cleanSpeechText}
        </div>
      )}
    </div>
  );
};
