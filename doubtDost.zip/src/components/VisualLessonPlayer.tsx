/**
 * Nanban AI - Visual Lesson Player
 * 5-scene visual explainer with animated SVGs, synchronized subtitles,
 * Web Speech TTS narration, chapters, speed control, and student action buttons.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  FastForward,
  Layers,
  HelpCircle,
  ShieldCheck,
  X,
  Sparkles,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

interface Scene {
  sceneNumber: number;
  title: string;
  chapter: string;
  narration: string;
  subtitle: string;
  visualType: string;
  svgContent: string;
  analogyCallout?: string;
  keyTakeaway?: string;
}

interface VisualLessonData {
  topic: string;
  analogyTheme: string;
  scenes: Scene[];
}

interface VisualLessonPlayerProps {
  lessonData: VisualLessonData;
  onClose: () => void;
  onQuizMe: () => void;
  onWhyThisVideo: () => void;
  onDifferentExample?: () => void;
}

export const VisualLessonPlayer: React.FC<VisualLessonPlayerProps> = ({
  lessonData,
  onClose,
  onQuizMe,
  onWhyThisVideo,
  onDifferentExample,
}) => {
  const [currentSceneIdx, setCurrentSceneIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState<boolean>(true);
  const [muted, setMuted] = useState<boolean>(false);

  const scene = lessonData.scenes[currentSceneIdx] || lessonData.scenes[0];
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Play narration with Web Speech API
  const playCurrentNarration = (text: string, rate: number) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    if (muted) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate;
    utterance.onend = () => {
      // Auto advance to next scene if playing
      if (isPlaying && currentSceneIdx + 1 < lessonData.scenes.length) {
        setCurrentSceneIdx((idx) => idx + 1);
      } else {
        setIsPlaying(false);
      }
    };
    speechRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (isPlaying && scene) {
      playCurrentNarration(scene.narration, playbackSpeed);
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    }

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [currentSceneIdx, isPlaying, playbackSpeed, muted, scene]);

  const togglePlay = () => {
    setIsPlaying((prev) => !prev);
  };

  const handleNext = () => {
    if (currentSceneIdx + 1 < lessonData.scenes.length) {
      setCurrentSceneIdx((idx) => idx + 1);
    }
  };

  const handlePrev = () => {
    if (currentSceneIdx > 0) {
      setCurrentSceneIdx((idx) => idx - 1);
    }
  };

  const cycleSpeed = () => {
    const speeds = [0.75, 1, 1.25, 1.5];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    setPlaybackSpeed(speeds[nextIdx]);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-white overflow-y-auto">
      {/* Top Header */}
      <div className="p-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-semibold text-[10px] tracking-wide uppercase">
            Visual Lesson
          </span>
          <span className="text-xs font-semibold text-slate-200 truncate max-w-[180px]">{lessonData.topic}</span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Main Visual Display */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
        {/* Verification & AI tag */}
        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1 text-teal-400 font-medium">
            <ShieldCheck className="w-3.5 h-3.5" />
            Script Agent & Visual Agent Verified
          </span>
          <span className="text-slate-500">AI-generated visual • Verify with your notes</span>
        </div>

        {/* Scene SVG Box */}
        <div className="relative w-full aspect-[16/10] bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl flex items-center justify-center">
          {scene?.svgContent ? (
            <div
              className="w-full h-full flex items-center justify-center p-2"
              dangerouslySetInnerHTML={{ __html: scene.svgContent }}
            />
          ) : (
            <div className="text-slate-500 text-xs">Visualizing scene...</div>
          )}

          {/* Subtitles Overlay */}
          {subtitlesEnabled && scene?.subtitle && (
            <div className="absolute bottom-3 left-4 right-4 bg-black/75 backdrop-blur-md px-3.5 py-1.5 rounded-xl text-center text-xs text-slate-100 font-medium border border-white/10 shadow-lg">
              {scene.subtitle}
            </div>
          )}
        </div>

        {/* Scene Info & Analogy */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-teal-400">{scene?.chapter}</span>
            <span className="text-slate-400">
              Scene {currentSceneIdx + 1} / {lessonData.scenes.length}
            </span>
          </div>
          <h4 className="text-base font-bold text-white">{scene?.title}</h4>
          <p className="text-xs text-slate-300 leading-relaxed">{scene?.narration}</p>

          {scene?.analogyCallout && (
            <div className="p-2.5 rounded-xl bg-indigo-950/60 border border-indigo-800/50 text-xs text-indigo-200 flex items-start gap-2">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
              <span>
                <strong>Analogy ({lessonData.analogyTheme}):</strong> {scene.analogyCallout}
              </span>
            </div>
          )}
        </div>

        {/* Timeline Chapter Selector */}
        <div className="flex gap-1.5 overflow-x-auto py-1 no-scrollbar">
          {lessonData.scenes.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSceneIdx(idx)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer shrink-0 border ${
                currentSceneIdx === idx
                  ? 'bg-teal-500 text-slate-950 border-teal-500 font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {s.chapter.split(':')[0] || `Scene ${idx + 1}`}
            </button>
          ))}
        </div>

        {/* Video Controls Bar */}
        <div className="bg-slate-900/90 rounded-2xl p-3 border border-slate-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1">
            <button
              onClick={handlePrev}
              disabled={currentSceneIdx === 0}
              className="p-2 rounded-xl text-slate-300 hover:bg-slate-800 disabled:opacity-30 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={togglePlay}
              className="p-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold transition cursor-pointer shadow-md shadow-teal-500/20"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            </button>
            <button
              onClick={handleNext}
              disabled={currentSceneIdx + 1 === lessonData.scenes.length}
              className="p-2 rounded-xl text-slate-300 hover:bg-slate-800 disabled:opacity-30 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={cycleSpeed}
              className="px-2 py-1 rounded-lg bg-slate-800 text-[11px] font-semibold text-slate-300 hover:text-white transition cursor-pointer"
            >
              {playbackSpeed}x
            </button>
            <button
              onClick={() => setSubtitlesEnabled(!subtitlesEnabled)}
              className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                subtitlesEnabled ? 'bg-teal-500/20 text-teal-300' : 'bg-slate-800 text-slate-400'
              }`}
            >
              CC
            </button>
            <button
              onClick={() => setMuted(!muted)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Student Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
          <button
            onClick={() => {
              setPlaybackSpeed(0.75);
              setIsPlaying(true);
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850 transition cursor-pointer text-center"
          >
            Explain slowly
          </button>
          {onDifferentExample && (
            <button
              onClick={onDifferentExample}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850 transition cursor-pointer text-center"
            >
              Different example
            </button>
          )}
          <button
            onClick={onWhyThisVideo}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-teal-400 hover:bg-slate-850 transition cursor-pointer text-center flex items-center justify-center gap-1"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Why this video?
          </button>
          <button
            onClick={onQuizMe}
            className="p-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium transition cursor-pointer text-center flex items-center justify-center gap-1"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            Quiz me
          </button>
        </div>
      </div>
    </div>
  );
};
