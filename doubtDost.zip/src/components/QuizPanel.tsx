/**
 * Nanban AI - Comprehensive Understanding Quiz & Activities Panel
 * 8-question dynamic quiz, before/after confidence rating, kind feedback (never red),
 * mistake notebook recording, planner task suggestions with Approve/Edit/Reject,
 * and interest-based learning activities.
 */

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  X,
  HelpCircle,
  Star,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Sparkles,
  BookOpen,
  CalendarPlus,
  RefreshCw,
  Trophy,
} from 'lucide-react';
import { QuizQuestion, MistakeItem, StudyPlanItem } from '../types';

interface QuizPanelProps {
  topic: string;
  questions: QuizQuestion[];
  onClose: () => void;
  onSaveResult: (result: {
    score: number;
    total: number;
    beforeConfidence: number;
    afterConfidence: number;
    strongConcepts: string[];
    weakConcepts: string[];
  }) => void;
  onAddMistake: (mistake: Omit<MistakeItem, 'id' | 'date'>) => void;
  onSuggestPlan: (task: Omit<StudyPlanItem, 'id' | 'createdAt'>) => void;
  interests?: string[];
  onOpenActivities?: (topic: string) => void;
}

export const QuizPanel: React.FC<QuizPanelProps> = ({
  topic,
  questions,
  onClose,
  onSaveResult,
  onAddMistake,
  onSuggestPlan,
  interests = [],
  onOpenActivities,
}) => {
  // States: 'before_rating' -> 'in_quiz' -> 'after_rating' -> 'completed'
  const [phase, setPhase] = useState<'before_rating' | 'in_quiz' | 'after_rating' | 'completed'>('before_rating');
  const [beforeConfidence, setBeforeConfidence] = useState<number>(3);
  const [afterConfidence, setAfterConfidence] = useState<number>(4);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [textInput, setTextInput] = useState<string>('');
  const [showFeedback, setShowFeedback] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);

  const [score, setScore] = useState<number>(0);
  const [weakConcepts, setWeakConcepts] = useState<string[]>([]);
  const [strongConcepts, setStrongConcepts] = useState<string[]>([]);

  // Planner revision approval state
  const [plannerApproved, setPlannerApproved] = useState<boolean | null>(null);

  const currentQ = questions[currentIndex];

  const handleStartQuiz = () => {
    setPhase('in_quiz');
    setCurrentIndex(0);
  };

  const handleAnswerSubmit = () => {
    if (!currentQ) return;
    const answer = (currentQ.type === 'fill_blank' || currentQ.type === 'short_answer') ? textInput.trim() : selectedOption;
    if (!answer) return;

    const correct = answer.toLowerCase() === currentQ.correctAnswer.toLowerCase();
    setIsCorrect(correct);
    setShowFeedback(true);

    setUserAnswers((prev) => ({ ...prev, [currentQ.id]: answer }));

    if (correct) {
      setScore((s) => s + 1);
      if (!strongConcepts.includes(currentQ.conceptTested)) {
        setStrongConcepts((sc) => [...sc, currentQ.conceptTested]);
      }
    } else {
      if (!weakConcepts.includes(currentQ.conceptTested)) {
        setWeakConcepts((wc) => [...wc, currentQ.conceptTested]);
      }
      // Save mistake to notebook
      onAddMistake({
        topic,
        question: currentQ.question,
        userAnswer: answer,
        correctAnswer: currentQ.correctAnswer,
        explanation: currentQ.explanation,
        reviewed: false,
      });
    }
  };

  const handleNextQuestion = () => {
    setShowFeedback(false);
    setSelectedOption('');
    setTextInput('');

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((idx) => idx + 1);
    } else {
      setPhase('after_rating');
    }
  };

  const handleFinishQuiz = () => {
    // Fire confetti celebration
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (e) {
      // Ignored if confetti fails
    }

    onSaveResult({
      score,
      total: questions.length,
      beforeConfidence,
      afterConfidence,
      strongConcepts,
      weakConcepts,
    });

    // If weak concepts exist, propose a revision task to Planner Agent
    if (weakConcepts.length > 0) {
      onSuggestPlan({
        day: 'Tomorrow',
        topic,
        task: `15-min flashcard & concept recap on: ${weakConcepts.join(', ')}`,
        status: 'pending',
        approved: false,
        origin: 'planner_agent',
      });
    }

    setPhase('completed');
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-y-auto">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40 sticky top-0 z-10 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
            <HelpCircle className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-sm text-slate-900 dark:text-white leading-tight">Understanding Check</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[200px]">{topic}</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 md:p-6 flex-1 flex flex-col justify-between">
        {/* PHASE 1: BEFORE RATING */}
        {phase === 'before_rating' && (
          <div className="space-y-6 my-auto text-center">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <Sparkles className="w-7 h-7" />
            </div>

            <div>
              <h4 className="text-lg font-bold text-slate-900 dark:text-white">Ready to test yourself?</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                Before we start, how confident do you feel about <strong>{topic}</strong>?
              </p>
            </div>

            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setBeforeConfidence(val)}
                  className={`w-11 h-11 rounded-2xl flex flex-col items-center justify-center font-semibold text-sm transition cursor-pointer border ${
                    beforeConfidence === val
                      ? 'bg-teal-600 text-white border-teal-600 shadow-md shadow-teal-500/20 scale-105'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <Star className={`w-4 h-4 ${beforeConfidence >= val ? 'fill-current' : ''}`} />
                  <span className="text-[10px] mt-0.5">{val}</span>
                </button>
              ))}
            </div>

            <div className="text-xs text-slate-400">
              {beforeConfidence <= 2 ? '🌱 Just starting to grasp it' : beforeConfidence <= 4 ? '👍 Fairly clear' : '⚡ Complete mastery!'}
            </div>

            <div className="pt-2">
              <button
                onClick={handleStartQuiz}
                className="w-full py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-sm transition shadow-md shadow-teal-500/10 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Start {questions.length} Questions</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* PHASE 2: IN QUIZ */}
        {phase === 'in_quiz' && currentQ && (
          <div className="space-y-5">
            {/* Progress header */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                <span>
                  Question {currentIndex + 1} of {questions.length}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-medium text-slate-600 dark:text-slate-300">
                  {currentQ.difficulty} • {currentQ.type.replace('_', ' ').toUpperCase()}
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-teal-500 transition-all duration-300"
                  style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Question Text */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
              <span className="text-[11px] font-semibold text-teal-600 dark:text-teal-400 block mb-1">
                Concept: {currentQ.conceptTested}
              </span>
              <p className="text-sm font-semibold text-slate-900 dark:text-white leading-relaxed">
                {currentQ.question}
              </p>
            </div>

            {/* Options / Input */}
            <div className="space-y-2">
              {currentQ.options ? (
                currentQ.options.map((opt, i) => {
                  const isSelected = selectedOption === opt;
                  return (
                    <button
                      key={i}
                      type="button"
                      disabled={showFeedback}
                      onClick={() => setSelectedOption(opt)}
                      className={`w-full text-left p-3 rounded-xl border text-xs md:text-sm transition cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'border-teal-500 bg-teal-500/10 dark:bg-teal-500/20 text-slate-900 dark:text-white font-medium'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-850 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <span>{opt}</span>
                      {isSelected && <div className="w-2 h-2 rounded-full bg-teal-500 shrink-0" />}
                    </button>
                  );
                })
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Your Answer (keyword or short phrase):
                  </label>
                  <input
                    type="text"
                    disabled={showFeedback}
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="Type your answer here..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                  />
                </div>
              )}
            </div>

            {/* Kind Feedback Banner (Never red; soft orange for incorrect) */}
            {showFeedback && (
              <div
                className={`p-3.5 rounded-xl text-xs md:text-sm border transition ${
                  isCorrect
                    ? 'bg-teal-500/10 border-teal-500/30 text-teal-900 dark:text-teal-200'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-200'
                }`}
              >
                <div className="flex items-start gap-2">
                  {isCorrect ? (
                    <CheckCircle className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <strong className="block mb-0.5">
                      {isCorrect ? 'Spot on! Great work.' : `Not quite — the correct answer is "${currentQ.correctAnswer}"`}
                    </strong>
                    <p className="leading-relaxed opacity-90">{currentQ.explanation}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-2">
              {!showFeedback ? (
                <button
                  type="button"
                  onClick={handleAnswerSubmit}
                  disabled={!selectedOption && !textInput.trim()}
                  className="w-full py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-sm transition cursor-pointer disabled:opacity-40"
                >
                  Check Answer
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleNextQuestion}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-medium text-sm transition cursor-pointer flex items-center justify-center gap-2 hover:opacity-90"
                >
                  <span>{currentIndex + 1 < questions.length ? 'Next Question' : 'View Results'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* PHASE 3: AFTER RATING */}
        {phase === 'after_rating' && (
          <div className="space-y-6 my-auto text-center">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Trophy className="w-7 h-7" />
            </div>

            <div>
              <h4 className="text-lg font-bold text-slate-900 dark:text-white">Questions Completed!</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                How confident do you feel about <strong>{topic}</strong> now?
              </p>
            </div>

            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAfterConfidence(val)}
                  className={`w-11 h-11 rounded-2xl flex flex-col items-center justify-center font-semibold text-sm transition cursor-pointer border ${
                    afterConfidence === val
                      ? 'bg-amber-600 text-white border-amber-600 shadow-md shadow-amber-500/20 scale-105'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <Star className={`w-4 h-4 ${afterConfidence >= val ? 'fill-current' : ''}`} />
                  <span className="text-[10px] mt-0.5">{val}</span>
                </button>
              ))}
            </div>

            <div className="text-xs text-slate-500">
              Confidence Change:{' '}
              <span className="font-semibold text-teal-600 dark:text-teal-400">
                {beforeConfidence} ⭐ ➔ {afterConfidence} ⭐ ({afterConfidence >= beforeConfidence ? `+${afterConfidence - beforeConfidence}` : `${afterConfidence - beforeConfidence}`})
              </span>
            </div>

            <button
              onClick={handleFinishQuiz}
              className="w-full py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-sm transition shadow-md shadow-teal-500/10 cursor-pointer"
            >
              See Detailed Analysis
            </button>
          </div>
        )}

        {/* PHASE 4: COMPLETED SUMMARY */}
        {phase === 'completed' && (
          <div className="space-y-5">
            <div className="text-center p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20">
              <span className="text-xs uppercase font-semibold text-teal-700 dark:text-teal-300 tracking-wider">
                Quiz Result
              </span>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
                {score} / {questions.length}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {score === questions.length
                  ? 'Flawless score! Concept fully assimilated.'
                  : score >= questions.length * 0.7
                  ? 'Strong grasp! A quick revision will make it perfect.'
                  : 'Good learning attempt! Reviewing the weak concepts below will lock it in.'}
              </p>
            </div>

            {/* Strong & Weak Concepts */}
            <div className="space-y-3">
              {strongConcepts.length > 0 && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
                  <span className="font-semibold text-emerald-800 dark:text-emerald-300 block mb-1">
                    ✓ Strong Concepts:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {strongConcepts.map((sc, i) => (
                      <span key={i} className="px-2 py-0.5 bg-emerald-500/20 rounded-md text-emerald-900 dark:text-emerald-100">
                        {sc}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {weakConcepts.length > 0 ? (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
                  <span className="font-semibold text-amber-800 dark:text-amber-300 block mb-1">
                    ⚠️ Saved to Mistake Notebook:
                  </span>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {weakConcepts.map((wc, i) => (
                      <span key={i} className="px-2 py-0.5 bg-amber-500/20 rounded-md text-amber-900 dark:text-amber-100">
                        {wc}
                      </span>
                    ))}
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    These items are available in your Progress ➔ Mistake Notebook for quick re-practice.
                  </span>
                </div>
              ) : null}
            </div>

            {/* Planner Agent Suggestion with Approve / Edit / Reject */}
            {weakConcepts.length > 0 && plannerApproved === null && (
              <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 text-xs space-y-2">
                <div className="flex items-center gap-1.5 font-semibold text-indigo-900 dark:text-indigo-200">
                  <CalendarPlus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>Planner Agent Suggestion</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 text-[11px]">
                  Would you like to schedule a 15-minute revision task for tomorrow for <strong>{weakConcepts[0]}</strong>?
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => setPlannerApproved(true)}
                    className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-medium text-xs hover:bg-indigo-500 transition cursor-pointer"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => setPlannerApproved(false)}
                    className="px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-xs hover:bg-slate-300 transition cursor-pointer"
                  >
                    Reject
                  </button>
                </div>
              </div>
            )}

            {plannerApproved === true && (
              <div className="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-800 dark:text-teal-200 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span>Revision task added to your Study Plan!</span>
              </div>
            )}

            {/* Interest-based Activities Button */}
            {onOpenActivities && (
              <div className="pt-2">
                <button
                  onClick={() => onOpenActivities(topic)}
                  className="w-full py-2.5 px-4 rounded-xl border border-indigo-200 dark:border-indigo-800/80 bg-indigo-50/60 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 font-semibold text-xs transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Try Gamified Activities & Analogies</span>
                </button>
              </div>
            )}

            <button
              onClick={onClose}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white font-medium text-xs hover:bg-slate-800 transition cursor-pointer"
            >
              Done with Quiz
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
