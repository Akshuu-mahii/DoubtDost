/**
 * Nanban AI - Robust Markdown Renderer
 * Renders Markdown tables with independent horizontal scrolling,
 * clean code blocks, bulleted lists, and readable typography (never raw | or ---).
 */

import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  return (
    <div className="prose prose-slate dark:prose-invert max-w-none text-[16px] md:text-[17px] leading-[1.7] text-slate-800 dark:text-slate-200">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          table({ children }) {
            return (
              <div className="my-4 overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 shadow-sm">
                <table className="w-full text-left text-xs md:text-sm border-collapse">{children}</table>
              </div>
            );
          },
          thead({ children }) {
            return <thead className="bg-slate-100/80 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 font-semibold">{children}</thead>;
          },
          th({ children }) {
            return <th className="p-3 border-b border-slate-200 dark:border-slate-800 font-semibold">{children}</th>;
          },
          td({ children }) {
            return <td className="p-3 border-b border-slate-100 dark:border-slate-800/60">{children}</td>;
          },
          h3({ children }) {
            return (
              <h3 className="text-base md:text-lg font-bold text-teal-800 dark:text-teal-300 mt-5 mb-2 pb-1 border-b border-teal-500/20 flex items-center gap-2">
                {children}
              </h3>
            );
          },
          h4({ children }) {
            return <h4 className="text-sm md:text-base font-bold text-slate-900 dark:text-white mt-4 mb-1.5">{children}</h4>;
          },
          ul({ children }) {
            return <ul className="my-2.5 space-y-1.5 list-disc pl-5 text-slate-700 dark:text-slate-300">{children}</ul>;
          },
          ol({ children }) {
            return <ol className="my-2.5 space-y-1.5 list-decimal pl-5 text-slate-700 dark:text-slate-300">{children}</ol>;
          },
          code({ inline, className, children, ...props }: any) {
            if (inline) {
              return (
                <code
                  className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-teal-700 dark:text-teal-300 text-xs md:text-sm font-mono"
                  {...props}
                >
                  {children}
                </code>
              );
            }
            return (
              <pre className="my-3 p-3.5 rounded-2xl bg-slate-900 text-slate-100 dark:bg-slate-950 overflow-x-auto text-xs md:text-sm font-mono border border-slate-800">
                <code>{children}</code>
              </pre>
            );
          },
          blockquote({ children }) {
            return (
              <blockquote className="my-3 border-l-4 border-teal-500 pl-4 py-1 italic bg-teal-50/40 dark:bg-teal-950/20 rounded-r-xl text-slate-700 dark:text-slate-300 text-sm">
                {children}
              </blockquote>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
};
