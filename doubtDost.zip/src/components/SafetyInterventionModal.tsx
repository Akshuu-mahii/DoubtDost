/**
 * Nanban AI - Safety & Support Intervention
 * Warm, compassionate, non-judgmental guidance for students in distress.
 * Soft amber styling (never alarming red). Displays saved trusted contact and 24/7 free helplines.
 */

import React from 'react';
import { HeartHandshake, PhoneCall, ShieldCheck, X, User } from 'lucide-react';
import { UserProfile } from '../types';

interface SafetyInterventionModalProps {
  warmMessage?: string;
  trustedContact?: UserProfile['trustedContact'];
  onClose: () => void;
}

export const SafetyInterventionModal: React.FC<SafetyInterventionModalProps> = ({
  warmMessage,
  trustedContact,
  onClose,
}) => {
  const helplines = [
    { name: 'Tele-MANAS (India Govt 24/7, Toll-Free)', number: '14416 / 1800-891-4416' },
    { name: 'AASRA 24/7 Suicide Prevention', number: '+91 98204 66726' },
    { name: 'Vandrevala Mental Health Foundation', number: '+91 9999 666 555' },
    { name: 'iCall Psychosocial Helpline', number: '9152987821' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700/60 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/15 text-amber-700 dark:text-amber-400 flex items-center justify-center">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">We care about you</h3>
              <span className="text-xs text-slate-500 dark:text-slate-400">Nanban AI Safety Support</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-950 dark:text-amber-100 text-xs md:text-sm leading-relaxed">
          {warmMessage ||
            "It sounds like things feel really heavy right now. Please know that you are deeply valued, and whatever you are facing, you do not have to carry it all alone. While I am an AI learning companion and cannot offer medical care or therapy, please reach out to someone you trust."}
        </div>

        {/* Saved Trusted Contact */}
        {trustedContact && trustedContact.phone && (
          <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-semibold text-indigo-900 dark:text-indigo-200">
              <User className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Your Saved Trusted Person: {trustedContact.name} ({trustedContact.relationship})</span>
            </div>
            <p className="text-slate-600 dark:text-slate-300">
              Consider texting or calling them right now: <strong className="text-indigo-600 dark:text-indigo-400">{trustedContact.phone}</strong>
            </p>
          </div>
        )}

        {/* 24/7 Helplines */}
        <div className="space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
            Free, Confidential 24/7 Support Lines
          </span>
          <div className="grid grid-cols-1 gap-2">
            {helplines.map((h, i) => (
              <div
                key={i}
                className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <span className="font-medium text-slate-800 dark:text-slate-200">{h.name}</span>
                <a
                  href={`tel:${h.number.split('/')[0].trim()}`}
                  className="px-2.5 py-1 rounded-lg bg-teal-500/15 text-teal-700 dark:text-teal-300 font-semibold hover:bg-teal-500/25 transition flex items-center gap-1"
                >
                  <PhoneCall className="w-3 h-3" />
                  {h.number}
                </a>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-[11px] text-slate-400">
            Nobody will be notified without your explicit choice.
          </span>
          <button
            onClick={onClose}
            className="py-2 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white font-medium text-xs hover:bg-slate-800 transition cursor-pointer"
          >
            I understand
          </button>
        </div>
      </div>
    </div>
  );
};
