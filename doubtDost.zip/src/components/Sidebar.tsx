/**
 * Doubt Dost - Left Sidebar Navigation
 * Collapsible on desktop, icon-mode on tablet, mobile responsive.
 * Contains: Logo, "New Chat" button, Chat History, Navigation Links,
 * Dark Mode toggle, and Student Profile Badge.
 */

import React from 'react';
import {
  MessageSquare,
  TrendingUp,
  Calendar,
  FileText,
  HeartHandshake,
  Settings,
  Plus,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  Sparkles,
  ClipboardList,
  Shield,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import { ChatSession } from '../types';

export type ActiveNavTab = 'chat' | 'progress' | 'study_plan' | 'notes' | 'checkin' | 'settings' | 'action_log';

interface SidebarProps {
  activeTab: ActiveNavTab;
  onSelectTab: (tab: ActiveNavTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  collapsed,
  onToggleCollapse,
}) => {
  const { profile, chats, currentChatId, selectChat, createNewChat } = useApp();
  const { theme, toggleTheme } = useTheme();

  const navItems: { id: ActiveNavTab; label: string; icon: React.FC<any> }[] = [
    { id: 'chat', label: 'Chat & Lessons', icon: MessageSquare },
    { id: 'progress', label: 'Progress & Mastery', icon: TrendingUp },
    { id: 'study_plan', label: 'Study Plan', icon: Calendar },
    { id: 'notes', label: 'Notes & Grounding', icon: FileText },
    { id: 'checkin', label: 'Friend & Mood', icon: HeartHandshake },
    { id: 'action_log', label: 'Agent Activity Log', icon: ClipboardList },
    { id: 'settings', label: 'Settings & Privacy', icon: Settings },
  ];

  return (
    <aside
      className={`h-full flex flex-col justify-between bg-white dark:bg-slate-900 border-r border-slate-200/80 dark:border-slate-800 transition-all duration-300 z-30 select-none ${
        collapsed ? 'w-16' : 'w-64 md:w-68'
      }`}
    >
      {/* Top Header & Logo */}
      <div className="p-3.5 border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
        {!collapsed ? (
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-500 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-sm shadow-teal-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="leading-tight">
              <span className="font-bold text-sm tracking-tight bg-gradient-to-r from-teal-600 to-indigo-600 dark:from-teal-400 dark:to-indigo-300 bg-clip-text text-transparent">
                DoubtDost
              </span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 block font-medium">டவுட் தோஸ்த்</span>
            </div>
          </div>
        ) : (
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-500 to-indigo-600 flex items-center justify-center text-white mx-auto shadow-sm shadow-teal-500/20">
            <Sparkles className="w-4 h-4" />
          </div>
        )}

        {/* Collapse toggle (Desktop) */}
        <button
          onClick={onToggleCollapse}
          className="hidden md:flex p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Middle Scrollable Section: New Chat + Nav Links + Recent Chats */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4 no-scrollbar">
        {/* New Chat Button */}
        <button
          onClick={() => {
            createNewChat();
            onSelectTab('chat');
          }}
          className={`w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-teal-200/80 dark:border-teal-800/60 font-semibold text-xs transition hover:bg-teal-100 dark:hover:bg-teal-900/40 cursor-pointer shadow-sm ${
            collapsed ? 'p-2' : ''
          }`}
          title="Start new learning session"
        >
          <Plus className="w-4 h-4 shrink-0" />
          {!collapsed && <span>New Chat</span>}
        </button>

        {/* Primary Navigation Links */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                  active
                    ? 'bg-teal-600 text-white font-semibold shadow-sm shadow-teal-500/20'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                } ${collapsed ? 'justify-center px-2' : ''}`}
                title={collapsed ? item.label : undefined}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Recent Chats */}
        {!collapsed && chats.length > 0 && (
          <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 space-y-1.5">
            <span className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Recent Chats
            </span>
            <div className="space-y-0.5 max-h-44 overflow-y-auto no-scrollbar">
              {chats.map((session) => {
                const active = activeTab === 'chat' && currentChatId === session.id;
                return (
                  <button
                    key={session.id}
                    onClick={() => {
                      selectChat(session.id);
                      onSelectTab('chat');
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs truncate transition cursor-pointer flex items-center gap-2 ${
                      active
                        ? 'bg-slate-100 dark:bg-slate-800 text-teal-600 dark:text-teal-400 font-semibold'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <MessageSquare className="w-3 h-3 shrink-0 text-slate-400" />
                    <span className="truncate">{session.title}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Footer: Theme Toggle & Local Student Profile Card */}
      <div className="p-3 border-t border-slate-200/80 dark:border-slate-800 space-y-2 bg-slate-50/50 dark:bg-slate-900/40">
        {/* Dark Mode & Theme */}
        {!collapsed && (
          <div className="flex items-center justify-between px-2 py-1 text-xs text-slate-500 dark:text-slate-400">
            <span>Theme</span>
            <button
              onClick={toggleTheme}
              className="flex items-center gap-1.5 px-2 py-0.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-3 h-3 text-amber-400" /> : <Moon className="w-3 h-3 text-indigo-400" />}
              <span className="text-[11px] capitalize">{theme}</span>
            </button>
          </div>
        )}

        {/* Student Profile Card (Local Device Storage) */}
        <div className="p-2 rounded-xl bg-white dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800 flex items-center gap-2.5 text-left">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-teal-500 to-indigo-500 text-white font-bold text-xs flex items-center justify-center shrink-0">
            {(profile.name || 'S')[0]?.toUpperCase()}
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                {profile.name || 'Student'}
              </p>
              <p className="text-[10px] text-teal-600 dark:text-teal-400 truncate flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" />
                <span>Saved locally</span>
              </p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
