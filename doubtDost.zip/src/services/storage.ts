/**
 * Doubt Dost - Browser Local Storage Service
 * Persists all student data strictly in the browser (localStorage / IndexedDB).
 * No remote database, no tracking, complete student privacy.
 */

import {
  UserProfile,
  ChatSession,
  ChatMessage,
  UserNote,
  QuizResult,
  MistakeItem,
  StudyPlanItem,
  MoodCheckin,
  ActionLog,
} from '../types';

const STORAGE_KEYS = {
  PROFILE: 'doubtdost_profile',
  CHATS: 'doubtdost_chats',
  MESSAGES_PREFIX: 'doubtdost_msgs_',
  NOTES: 'doubtdost_notes',
  QUIZZES: 'doubtdost_quizzes',
  MISTAKES: 'doubtdost_mistakes',
  PLAN: 'doubtdost_plan',
  CHECKINS: 'doubtdost_checkins',
  LOGS: 'doubtdost_logs',
  THEME: 'doubtdost_theme',
};

// Default empty profile
export const DEFAULT_PROFILE: UserProfile = {
  name: '',
  preferredLanguage: 'Auto-detect',
  level: 'Class 10',
  onboardingComplete: false,
  interests: [],
  pauseSaving: false,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

export const StorageService = {
  // Profile
  getProfile(): UserProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  },
  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Chats
  getChats(): ChatSession[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHATS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveChats(chats: ChatSession[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(chats));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Messages per Chat
  getMessages(chatId: string): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES_PREFIX + chatId);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveMessages(chatId: string, messages: ChatMessage[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.MESSAGES_PREFIX + chatId, JSON.stringify(messages));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },
  deleteChatMessages(chatId: string): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.MESSAGES_PREFIX + chatId);
    } catch (e) {
      console.warn('Storage delete failed:', e);
    }
  },

  // Notes
  getNotes(): UserNote[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveNotes(notes: UserNote[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Quizzes
  getQuizzes(): QuizResult[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.QUIZZES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveQuizzes(quizzes: QuizResult[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(quizzes));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Mistakes
  getMistakes(): MistakeItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MISTAKES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveMistakes(mistakes: MistakeItem[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.MISTAKES, JSON.stringify(mistakes));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Study Plan
  getPlan(): StudyPlanItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PLAN);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  savePlan(plan: StudyPlanItem[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.PLAN, JSON.stringify(plan));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Checkins
  getCheckins(): MoodCheckin[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHECKINS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveCheckins(checkins: MoodCheckin[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.CHECKINS, JSON.stringify(checkins));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Action Logs
  getLogs(): ActionLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.LOGS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },
  saveLogs(logs: ActionLog[]): void {
    try {
      const profile = this.getProfile();
      if (profile.pauseSaving) return;
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs.slice(0, 50)));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  // Clear All Data
  clearAll(): void {
    try {
      const keysToKeep = [STORAGE_KEYS.THEME];
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith('doubtdost_') && !keysToKeep.includes(key)) {
          localStorage.removeItem(key);
        }
      });
    } catch (e) {
      console.warn('Storage clear failed:', e);
    }
  },
};
