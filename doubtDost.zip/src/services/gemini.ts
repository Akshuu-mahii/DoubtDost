/**
 * Doubt Dost - Direct Gemini Client Service via @google/genai
 * Client-side direct streaming with gemini-3.8-flash.
 * Zero backend, zero Firebase.
 */

import { GoogleGenAI } from '@google/genai';
import { AnswerStyle, LearningModelType, QuizQuestion } from '../types';

// API Key initialization
function getApiKey(): string {
  return (
    process.env.GEMINI_API_KEY ||
    process.env.API_KEY ||
    (import.meta as any).env?.VITE_GEMINI_API_KEY ||
    (import.meta as any).env?.VITE_API_KEY ||
    ''
  );
}

let aiInstance: GoogleGenAI | null = null;
export function getGeminiClient(): GoogleGenAI | null {
  const key = getApiKey();
  if (!key) return null;
  if (!aiInstance) {
    try {
      aiInstance = new GoogleGenAI({ apiKey: key });
    } catch (err) {
      console.warn('Gemini client initialization error:', err);
    }
  }
  return aiInstance;
}

export const GEMINI_MODEL = 'gemini-3.8-flash';

// Friendly error translation
export function parseGeminiError(error: any): string {
  const msg = error?.message || String(error);
  const lower = msg.toLowerCase();

  if (lower.includes('429') || lower.includes('quota') || lower.includes('resource_exhausted')) {
    return '⚠️ Gemini API quota limit reached. Please wait a moment and click Retry.';
  }
  if (lower.includes('503') || lower.includes('demand') || lower.includes('overloaded')) {
    return '⚠️ The AI model is experiencing a temporary surge in traffic. Please wait a few seconds and click Retry.';
  }
  if (lower.includes('api_key') || lower.includes('401') || lower.includes('key not valid')) {
    return '⚠️ Invalid or missing Gemini API key. Please check your environment key configuration.';
  }
  if (lower.includes('network') || lower.includes('offline') || lower.includes('failed to fetch')) {
    return '⚠️ Network connection interrupted. Please check your internet connection and click Retry.';
  }
  return '⚠️ Could not complete response right now. Please click Retry.';
}

export interface StreamLessonParams {
  messages: { role: 'user' | 'assistant'; content: string }[];
  style: AnswerStyle;
  modelType?: LearningModelType;
  language: string;
  tryFirst: boolean;
  notesContext: string;
  studentLevel: string;
  studentInterests: string[];
  forceReveal?: boolean;
  onChunk: (text: string) => void;
  signal?: AbortSignal;
}

export async function streamLessonContent({
  messages,
  style,
  modelType = 'gemini-flash',
  language,
  tryFirst,
  notesContext,
  studentLevel,
  studentInterests,
  forceReveal = false,
  onChunk,
  signal,
}: StreamLessonParams): Promise<string> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('Gemini API key is not configured.');
  }

  const interestStr = studentInterests.length > 0 ? studentInterests.join(', ') : 'everyday sports or movies';

  // Specific model type directives
  let modelDirective = '';
  switch (modelType) {
    case 'deep-reasoning':
      modelDirective = `\n[MODE: Deep Reasoning] Emphasize first-principles logical deduction, step-by-step mathematical proofs, and dimensional unit checks.`;
      break;
    case 'socratic-tutor':
      modelDirective = `\n[MODE: Socratic Tutor] Guide the student with 1-2 thoughtful guiding questions and hints; encourage them to discover the answer themselves.`;
      break;
    case 'exam-specialist':
      modelDirective = `\n[MODE: Exam Specialist] Structure strictly for school & board exam marks. Bold key technical buzzwords, show point allocations, and flag common examiner deduction traps.`;
      break;
    case 'tanglish-bilingual':
      modelDirective = `\n[MODE: Tanglish & Colloquial Tamil] Use warm, friendly Tamil+English blend (e.g. "Romba simple nanba", "First indha concept-ah purinjukonga"). Keep science terms in clear English.`;
      break;
    case 'story-analogy':
      modelDirective = `\n[MODE: Story & Analogy] Connect the concept to the student's interests (${interestStr}) using vivid analogies.`;
      break;
    case 'quick-doubt':
      modelDirective = `\n[MODE: Quick Doubt] Deliver the exact definition, formula, and answer in under 4 high-yield bullet points with zero fluff.`;
      break;
    default:
      modelDirective = `\n[MODE: Balanced Tutor] Clear, comprehensive, and friendly explanation.`;
  }

  const systemInstruction = `You are DoubtDost, a kind, patient, friendly AI study companion for students.
Student Level: ${studentLevel}
Answer Style: ${style}
Language Setting: ${language}
Try-First Mode: ${tryFirst && !forceReveal ? 'ENABLED' : 'DISABLED'}
Student Interests: ${interestStr}
${modelDirective}

PEDAGOGICAL & ACCURACY RULES:
1. Auto-detect the language the student types in (English, Tamil, Tanglish, or mixed) and reply in the EXACT SAME language and conversational tone.
2. If Try-First mode is ENABLED:
   - Do NOT give the direct answer or final formula immediately!
   - Ask the student warmly what they think or to try the first step.
   - Give 1 gentle, encouraging hint using a relatable analogy (${interestStr}).
   - Tell them they can reply with their thought or click "Show full answer" anytime.
3. If style is "Detailed lesson", organize strictly into these 8 Markdown sections:
   ### 1. One-Line Simple Definition
   ### 2. Why It Matters & Real-Life Use
   ### 3. Step-by-Step Core Concepts (simple words first, then technical terms)
   ### 4. Worked Examples
   ### 5. Comparison Table (clean Markdown table | Header | Header |)
   ### 6. Visual Concept Flow (clean ASCII / flow diagram or step diagram)
   ### 7. Common Mistakes & Exam Tips
   ### 8. Quick Recap (3-5 bullet points)
4. If style is 2-mark, 5-mark, or 10-mark, structure strictly according to exam scoring with mark breakdowns, bulleted steps, and underlined keywords.
5. If style is "Quick revision", provide high-yield bullets, key formula, and 3 takeaways.
6. Truthfulness: Say "I'm not sure" instead of guessing. Never invent paper names, facts, or fake citations.
7. Grounding in Student Notes:
${notesContext ? `Student's uploaded notes excerpt:\n"""\n${notesContext}\n"""\nGround your answer directly in these notes. Highlight where the notes explain this.` : 'No student notes uploaded. State naturally that this is a general explanation.'}`;

  const recent = messages.slice(-8);
  const prompt = recent.map((m) => `${m.role === 'user' ? 'Student' : 'Doubt Dost'}: ${m.content}`).join('\n\n');

  let fullResponse = '';
  const responseStream = await ai.models.generateContentStream({
    model: GEMINI_MODEL,
    contents: prompt,
    config: {
      systemInstruction,
    },
  });

  for await (const chunk of responseStream) {
    if (signal?.aborted) {
      throw new Error('Streaming cancelled by student');
    }
    if (chunk.text) {
      fullResponse += chunk.text;
      onChunk(chunk.text);
    }
  }

  return fullResponse;
}

// 8+ Question Diagnostic Quiz Generation
export async function generateQuizDirect({
  topic,
  studentLevel,
  language,
  notesContext,
}: {
  topic: string;
  studentLevel: string;
  language: string;
  notesContext?: string;
}): Promise<QuizQuestion[]> {
  const ai = getGeminiClient();
  if (!ai) throw new Error('Gemini API key is not configured.');

  const prompt = `Generate a comprehensive diagnostic quiz on the topic: "${topic}".
Student Level: ${studentLevel}
Language: ${language}
${notesContext ? `Notes excerpt: ${notesContext.slice(0, 1500)}` : ''}

You MUST generate AT LEAST 8 questions with rising difficulty:
1. Easy MCQ (basic recall)
2. True / False (foundational statement)
3. Fill-in-the-blank (core definition or keyword)
4. Medium MCQ (application problem)
5. True / False (common pitfall / misconception)
6. Short answer (1-3 word keyword)
7. Hard MCQ (analytical or comparative)
8. Scenario question (real-world practical situation problem)

Return strictly valid JSON:
{
  "questions": [
    {
      "id": 1,
      "type": "mcq" | "true_false" | "fill_blank" | "short_answer" | "scenario",
      "difficulty": "Easy" | "Medium" | "Hard",
      "question": "Question text",
      "options": ["Option A", "Option B", "Option C", "Option D"], // or ["True", "False"] or null
      "correctAnswer": "Exact string of correct answer",
      "explanation": "Kind, clear explanation of why this answer is correct",
      "conceptTested": "Subconcept name"
    }
  ]
}`;

  try {
    const res = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(res.text || '{}');
    return Array.isArray(parsed.questions) && parsed.questions.length >= 8
      ? parsed.questions
      : fallbackQuestions(topic);
  } catch (err) {
    console.warn('Quiz generation fallback applied:', err);
    return fallbackQuestions(topic);
  }
}

// Fallback questions for resilience
function fallbackQuestions(topic: string): QuizQuestion[] {
  return [
    {
      id: 1,
      type: 'mcq',
      difficulty: 'Easy',
      question: `What is the core definition of ${topic}?`,
      options: ['Fundamental principle', 'Secondary factor', 'Unrelated rule', 'Random event'],
      correctAnswer: 'Fundamental principle',
      explanation: `${topic} builds from its foundational definition.`,
      conceptTested: 'Basic Definition',
    },
    {
      id: 2,
      type: 'true_false',
      difficulty: 'Easy',
      question: `${topic} directly applies to everyday real-world phenomena.`,
      options: ['True', 'False'],
      correctAnswer: 'True',
      explanation: 'Every scientific and mathematical concept connects to real physical or logical systems.',
      conceptTested: 'Real-world Relevance',
    },
    {
      id: 3,
      type: 'fill_blank',
      difficulty: 'Medium',
      question: `In studying ${topic}, the primary rate of change depends on ________.`,
      options: null,
      correctAnswer: 'variables',
      explanation: 'Rates of change govern the core dynamics.',
      conceptTested: 'Mechanism',
    },
    {
      id: 4,
      type: 'mcq',
      difficulty: 'Medium',
      question: `Which of the following is an accurate example of ${topic}?`,
      options: ['Working practical demonstration', 'Non-reactive static state', 'Zero-energy void', 'Isolated anomaly'],
      correctAnswer: 'Working practical demonstration',
      explanation: 'Demonstrations illustrate transformation pathways.',
      conceptTested: 'Application',
    },
    {
      id: 5,
      type: 'true_false',
      difficulty: 'Medium',
      question: `A common exam mistake is assuming ${topic} is constant under all environmental changes.`,
      options: ['True', 'False'],
      correctAnswer: 'True',
      explanation: 'Boundary conditions like temperature and pressure modify behavior.',
      conceptTested: 'Boundary Conditions',
    },
    {
      id: 6,
      type: 'short_answer',
      difficulty: 'Hard',
      question: `Name one essential measurement unit or metric associated with ${topic}:`,
      options: null,
      correctAnswer: 'unit',
      explanation: 'Dimensional units allow quantified analysis.',
      conceptTested: 'Measurement',
    },
    {
      id: 7,
      type: 'mcq',
      difficulty: 'Hard',
      question: `When comparing ${topic} to alternative approaches, what is the primary benefit?`,
      options: ['High predictability and conservation', 'Lower accuracy', 'Zero reproducibility', 'High error probability'],
      correctAnswer: 'High predictability and conservation',
      explanation: 'Predictability enables scientific control.',
      conceptTested: 'Comparison',
    },
    {
      id: 8,
      type: 'scenario',
      difficulty: 'Hard',
      question: `In an exam problem where ${topic} is tested with a surprise variable, what should you verify first?`,
      options: ['Check boundary conditions and conservation laws', 'Guess the final answer', 'Skip units', 'Assume infinite rate'],
      correctAnswer: 'Check boundary conditions and conservation laws',
      explanation: 'Fundamental laws prevent unforced calculation errors.',
      conceptTested: 'Exam Strategy',
    },
  ];
}

// TruthCheck Grounding Analysis
export async function verifyLessonDirect({
  answer,
  notesContext,
  topic,
}: {
  answer: string;
  notesContext: string;
  topic: string;
}) {
  if (!notesContext || notesContext.trim().length === 0) {
    return {
      status: 'General answer, not from your notes' as const,
      sources: ['General AI Knowledge Base (Curriculum-aligned)'],
      notesMatchCount: 0,
      summary: 'No student notes uploaded for this topic. Generated from curriculum-aligned knowledge.',
    };
  }

  const ai = getGeminiClient();
  if (!ai) {
    return {
      status: 'Partly verified' as const,
      sources: ['Uploaded student notes excerpt'],
      notesMatchCount: 2,
      summary: 'Keyword matched against uploaded notes.',
    };
  }

  const prompt = `You are TruthCheck Agent for DoubtDost.
Verify this lesson answer against the student's uploaded notes excerpt.
Topic: ${topic}
Notes Excerpt:
"""
${notesContext.slice(0, 2500)}
"""

Generated Answer:
"""
${answer.slice(0, 2500)}
"""

Determine if the answer is:
- "Verified": fully supported by notes
- "Partly verified": partially supported or general curriculum additions
- "Not verified": contradicts notes

Return JSON strictly:
{
  "status": "Verified" | "Partly verified" | "Not verified",
  "sources": ["specific page, formula, or concept from notes"],
  "notesMatchCount": 3,
  "summary": "1-2 sentence verification explanation"
}`;

  try {
    const res = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: 'application/json' },
    });
    return JSON.parse(res.text || '{}');
  } catch (err) {
    return {
      status: 'Partly verified' as const,
      sources: ['Uploaded student notes'],
      notesMatchCount: 2,
      summary: 'Verified against notes keywords.',
    };
  }
}

// Gamified Activities Generator
export async function generateActivitiesDirect({
  topic,
  interests,
}: {
  topic: string;
  interests: string[];
}) {
  const ai = getGeminiClient();
  const interest = interests[0] || 'sports';

  if (!ai) return fallbackActivities(topic, interest);

  const prompt = `Create 6 interactive learning activities for a student who learned "${topic}" and loves "${interest}".
Return JSON:
{
  "activities": [
    {
      "id": "scenario",
      "type": "Scenario Puzzle",
      "title": "Real-World Challenge",
      "description": "Connecting ${topic} with ${interest}",
      "task": "Specific puzzle prompt"
    },
    {
      "id": "analogy",
      "type": "Analogy Card",
      "title": "${interest.toUpperCase()} Analogy",
      "description": "How ${topic} works just like a mechanic in ${interest}",
      "task": "Think through the analogy: ..."
    },
    {
      "id": "story",
      "type": "Story Mode",
      "title": "Narrative Journey",
      "description": "A short story where ${topic} saves the day",
      "task": "What choice would you make next?"
    },
    {
      "id": "pairs",
      "type": "Match the Pairs",
      "title": "Pairing Challenge",
      "description": "Match 4 concepts with descriptions",
      "pairs": [
        {"left": "Concept 1", "right": "Description 1"},
        {"left": "Concept 2", "right": "Description 2"},
        {"left": "Concept 3", "right": "Description 3"},
        {"left": "Concept 4", "right": "Description 4"}
      ]
    },
    {
      "id": "meme",
      "type": "Meme & Caption Challenge",
      "title": "Explain Like I'm 5 Meme",
      "description": "Funniest, most accurate caption",
      "task": "Write your caption..."
    },
    {
      "id": "project",
      "type": "Mini Project Idea",
      "title": "15-Minute Builder",
      "description": "Hands-on mini project",
      "task": "Instructions..."
    }
  ]
}`;

  try {
    const res = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: 'application/json' },
    });
    const parsed = JSON.parse(res.text || '{}');
    return parsed.activities || fallbackActivities(topic, interest);
  } catch (err) {
    return fallbackActivities(topic, interest);
  }
}

function fallbackActivities(topic: string, interest: string) {
  return [
    {
      id: 'scenario',
      type: 'Scenario Puzzle',
      title: `The ${topic} Investigation`,
      description: `Apply ${topic} principles to solve a practical puzzle.`,
      task: `How would you utilize the core properties of ${topic} to maximize efficiency in a real ${interest} project?`,
    },
    {
      id: 'analogy',
      type: 'Analogy Card',
      title: 'The Relatable Analogy',
      description: `Compare ${topic} to ${interest}.`,
      task: `Explain to a friend how ${topic} operates just like your favorite play or character in ${interest}.`,
    },
    {
      id: 'pairs',
      type: 'Match the Pairs',
      title: 'Speed Match',
      description: 'Match key concepts to their definitions.',
      pairs: [
        { left: 'Primary Definition', right: 'The foundational statement' },
        { left: 'Boundary Condition', right: 'Limits where rules apply' },
        { left: 'Rate / Transfer', right: 'Speed of transformation' },
        { left: 'Conservation', right: 'Balance preserved throughout' },
      ],
    },
  ];
}

// Safety Check (keyword + model)
export function runFastSafetyCheck(text: string): { distressed: boolean; warmMessage?: string } {
  const distressKeywords = [
    'suicide',
    'kill myself',
    'end my life',
    'self harm',
    'want to die',
    'no reason to live',
    'hurt myself',
    'cannot go on',
    'hopeless',
    'depressed and lonely',
  ];

  const lower = text.toLowerCase();
  const matched = distressKeywords.some((k) => lower.includes(k));

  if (matched) {
    return {
      distressed: true,
      warmMessage:
        "I hear that you're going through a very heavy and painful moment. Please know that you are not alone, and your safety and well-being matter so much. While I'm an AI learning companion and cannot provide therapy or medical care, please reach out right away to someone who cares about you or a free, confidential helpline.",
    };
  }
  return { distressed: false };
}
