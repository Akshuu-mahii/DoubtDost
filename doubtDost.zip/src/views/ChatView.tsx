/**
 * Doubt Dost - Chat & Detailed Lessons View
 * Token-by-token streaming directly via @google/genai.
 * "What do you want to learn today?" empty state.
 * Answer styles (Detailed lesson, 2-mark, 5-mark, 10-mark, Quick revision).
 * "Try first" toggle, "Purinjudha?" thumbs up/down, Sources panel with Verified badge.
 * Soft orange error handling with Retry (never saved as an answer).
 * Scrolling model type selector and typewriter follow-scroll.
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Sparkles,
  StopCircle,
  ThumbsUp,
  ThumbsDown,
  HelpCircle,
  Volume2,
  ShieldCheck,
  RotateCcw,
  BookOpen,
  ArrowRight,
  SplitSquareVertical,
  CheckCircle2,
  Lightbulb,
  ArrowDown,
  Lock,
  Unlock,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { MarkdownRenderer } from '../components/MarkdownRenderer';
import { ScrollingModelSelector, MODEL_OPTIONS } from '../components/ScrollingModelSelector';
import { ChatMessage, AnswerStyle, UserNote, LearningModelType } from '../types';
import { useApp } from '../context/AppContext';

interface ChatViewProps {
  onSendMessage: (
    text: string,
    style: AnswerStyle,
    tryFirst: boolean,
    modelType: LearningModelType
  ) => Promise<void>;
  onStopStreaming: () => void;
  isStreaming: boolean;
  streamError: string | null;
  onRetry: () => void;
  onWhyThisAnswer: (message: ChatMessage) => void;
  onStartQuiz: (topic: string, preGeneratedQuiz?: any) => void;
  onFeedback: (messageId: string, feedback: 'positive' | 'negative') => void;
  onReExplainSimply: (originalMessage: ChatMessage) => void;
}

const STYLE_OPTIONS: { id: AnswerStyle; label: string; desc: string }[] = [
  { id: 'Detailed lesson', label: 'Detailed Lesson', desc: '8-step structured teacher notes' },
  { id: '2-mark', label: '2-Mark', desc: 'Concise exam definition' },
  { id: '5-mark', label: '5-Mark', desc: 'Points with diagram/flow' },
  { id: '10-mark', label: '10-Mark', desc: 'Exhaustive essay format' },
  { id: 'Quick revision', label: 'Quick Revision', desc: 'High-yield points & recap' },
];

export const ChatView: React.FC<ChatViewProps> = ({
  onSendMessage,
  onStopStreaming,
  isStreaming,
  streamError,
  onRetry,
  onWhyThisAnswer,
  onStartQuiz,
  onFeedback,
  onReExplainSimply,
}) => {
  const { profile, messages, notes } = useApp();
  const [inputText, setInputText] = useState<string>('');
  const [selectedStyle, setSelectedStyle] = useState<AnswerStyle>('Detailed lesson');
  const [selectedModel, setSelectedModel] = useState<LearningModelType>('gemini-flash');
  const [tryFirstMode, setTryFirstMode] = useState<boolean>(false);

  // Typewriter Auto-Scroll state & detection
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState<boolean>(true);
  const [userScrolledUp, setUserScrolledUp] = useState<boolean>(false);

  // Scroll detection
  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    setUserScrolledUp(distanceToBottom > 120);
  };

  useEffect(() => {
    if (autoScrollEnabled && !userScrolledUp) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, autoScrollEnabled, userScrolledUp]);

  const scrollToBottom = () => {
    setUserScrolledUp(false);
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isStreaming) return;
    const text = inputText;
    setInputText('');
    setUserScrolledUp(false);
    onSendMessage(text, selectedStyle, tryFirstMode, selectedModel);
  };

  const getGreeting = () => {
    const name = profile.name;
    return name ? `Hello, ${name}!` : 'Hello!';
  };

  const currentModelOption = MODEL_OPTIONS.find((m) => m.id === selectedModel) || MODEL_OPTIONS[0];

  return (
    <div className="flex-1 flex flex-col h-full min-h-0 bg-transparent relative">
      {/* Scrollable Messages Area */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-6 relative"
      >
        {messages.length === 0 ? (
          /* Empty Chat View ("What do you want to learn today?") */
          <div className="max-w-2xl mx-auto my-auto text-center py-12 md:py-20 space-y-5">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-teal-500/20 to-indigo-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center shadow-lg shadow-teal-500/10">
              <Sparkles className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                {getGreeting()}
              </h2>
              <p className="text-sm md:text-base text-slate-600 dark:text-slate-400 mt-2 font-medium">
                What do you want to learn today?
              </p>
            </div>

            {/* Empty state prompt suggestions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-xl mx-auto pt-4 text-xs">
              {[
                'Photosynthesis light and dark reactions',
                "Newton's laws of motion with sports analogy",
                'Derive quadratic formula step by step',
                'DNA replication and transcription difference',
              ].map((suggestion, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setInputText(suggestion)}
                  className="p-3 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-850/60 hover:border-teal-500/60 text-slate-700 dark:text-slate-300 text-left transition cursor-pointer shadow-sm hover:shadow-md"
                >
                  <span className="font-semibold text-teal-700 dark:text-teal-300 block mb-0.5">Topic Idea</span>
                  <span className="opacity-90">{suggestion}</span>
                </button>
              ))}
            </div>

            <p className="text-xs text-slate-400 dark:text-slate-500 pt-2">
              Type in English, தமிழ் (Tamil), or Tanglish. DoubtDost will auto-detect and reply in your language.
            </p>
          </div>
        ) : (
          /* Render Messages */
          <div className="max-w-3xl mx-auto space-y-6">
            {messages.map((msg, index) => {
              const isUser = msg.role === 'user';
              const msgModel = MODEL_OPTIONS.find((m) => m.id === msg.modelType);
              return (
                <div
                  key={msg.id || index}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-2`}
                >
                  {/* Bubble Container */}
                  <div
                    className={`rounded-2xl p-4 md:p-6 transition-all ${
                      isUser
                        ? 'bg-gradient-to-r from-teal-600 to-indigo-600 text-white max-w-xl shadow-md shadow-teal-500/10'
                        : 'w-full bg-white/90 dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800 shadow-sm'
                    }`}
                  >
                    {!isUser && (
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100 dark:border-slate-800/80 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-teal-600 dark:text-teal-400 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5" />
                            DoubtDost
                          </span>
                          {msgModel && (
                            <span className="px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60 text-[10px] font-semibold flex items-center gap-1">
                              <span>{msgModel.icon}</span>
                              <span>{msgModel.name}</span>
                            </span>
                          )}
                          {msg.style && (
                            <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-300">
                              {msg.style}
                            </span>
                          )}
                        </div>

                        {/* TruthCheck Grounding Chip */}
                        <button
                          onClick={() => onWhyThisAnswer(msg)}
                          className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium transition cursor-pointer border ${
                            msg.truthCheckStatus === 'Verified'
                              ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
                              : msg.truthCheckStatus === 'Partly verified'
                              ? 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                          }`}
                          title="Click to view grounding sources"
                        >
                          <ShieldCheck className="w-3 h-3" />
                          <span>{msg.truthCheckStatus || (notes.length > 0 ? 'Verified in Notes' : 'General answer, not from your notes')}</span>
                        </button>
                      </div>
                    )}

                    {/* Message Body */}
                    {isUser ? (
                      <p className="text-[15px] md:text-base leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                    ) : (
                      <MarkdownRenderer content={msg.content} />
                    )}

                    {/* Action Bar for AI Answers */}
                    {!isUser && !msg.streaming && (
                      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2.5 text-xs text-slate-600 dark:text-slate-400">
                        {/* Purinjudha? Thumbs Up / Down */}
                        <div className="flex items-center gap-1">
                          <span className="font-semibold text-slate-500 text-[11px] mr-1">Purinjudha?</span>
                          <button
                            onClick={() => onFeedback(msg.id, 'positive')}
                            className={`p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer ${
                              msg.feedback === 'positive' ? 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40' : ''
                            }`}
                            title="Understood clearly"
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              onFeedback(msg.id, 'negative');
                              onReExplainSimply(msg);
                            }}
                            className={`p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer ${
                              msg.feedback === 'negative' ? 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40' : ''
                            }`}
                            title="Need simpler explanation with a different example"
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Interactive Learning Buttons */}
                        <div className="flex flex-wrap items-center gap-1.5">
                          {/* Why this answer? */}
                          <button
                            onClick={() => onWhyThisAnswer(msg)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer text-slate-700 dark:text-slate-300"
                          >
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                            <span>Why this answer?</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Ready to Test Yourself Banner after detailed lesson */}
                  {!isUser && !msg.streaming && (
                    <div className="w-full flex items-center justify-between p-3 rounded-2xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-800/60 text-xs">
                      <div className="flex items-center gap-2">
                        <HelpCircle className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                        <span className="font-semibold text-teal-900 dark:text-teal-200">
                          Ready to test your understanding?
                        </span>
                      </div>
                      <button
                        onClick={() => onStartQuiz(messages[index - 1]?.content || 'this topic', msg.quizPreGenerated)}
                        className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold transition cursor-pointer flex items-center gap-1 shadow-sm"
                      >
                        <span>Take 8-Question Diagnostic Quiz</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Streaming Typing Indicator */}
            {isStreaming && (
              <div className="flex items-center gap-2 text-xs text-teal-600 dark:text-teal-400 p-3 bg-teal-50/50 dark:bg-teal-950/30 rounded-2xl border border-teal-200/50">
                <div className="w-2 h-2 rounded-full bg-teal-500 animate-ping" />
                <span>{currentModelOption.name} is typing & crafting your lesson...</span>
              </div>
            )}

            {/* Soft Orange Stream Error Banner with Retry (Never saved as an answer) */}
            {streamError && !isStreaming && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs flex items-center justify-between gap-3 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>{streamError}</span>
                </div>
                <button
                  type="button"
                  onClick={onRetry}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold transition cursor-pointer flex items-center gap-1 shrink-0"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry</span>
                </button>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        )}

        {/* Floating "Scroll to latest" button when user scrolled up during typing/reading */}
        {userScrolledUp && (
          <button
            type="button"
            onClick={scrollToBottom}
            className="sticky bottom-4 left-1/2 -translate-x-1/2 mx-auto flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 dark:bg-white/90 text-white dark:text-slate-900 text-xs font-semibold shadow-xl border border-white/20 backdrop-blur-md cursor-pointer hover:scale-105 transition-all z-20"
          >
            <ArrowDown className="w-3.5 h-3.5" />
            <span>{isStreaming ? 'New tokens typing... Jump to bottom' : 'Scroll to bottom'}</span>
            {isStreaming && <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />}
          </button>
        )}
      </div>

      {/* Fixed Bottom Input Bar, Scrolling Model Selector & Style Selector */}
      <div className="border-t border-slate-200/80 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md p-3 md:p-4 space-y-2.5">
        <div className="max-w-3xl mx-auto space-y-2.5">
          {/* 1. SCROLLING TYPE MODEL SELECTOR CAROUSEL */}
          <ScrollingModelSelector
            selectedModel={selectedModel}
            onSelectModel={(model) => setSelectedModel(model)}
            compact={false}
          />

          {/* 2. Answer Style Selector Pills, Try-First Mode & Auto-Scroll Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1 border-t border-slate-100 dark:border-slate-800/60">
            {/* Style Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase mr-1">
                Format:
              </span>
              {STYLE_OPTIONS.map((style) => (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => setSelectedStyle(style.id)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition cursor-pointer border ${
                    selectedStyle === style.id
                      ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                  }`}
                  title={style.desc}
                >
                  {style.label}
                </button>
              ))}
            </div>

            {/* Right controls: Try-First Mode Toggle + Auto-Scroll Toggle */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setAutoScrollEnabled(!autoScrollEnabled)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-medium transition cursor-pointer border ${
                  autoScrollEnabled
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    : 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30'
                }`}
                title={autoScrollEnabled ? 'Auto-scroll is ON' : 'Auto-scroll is paused'}
              >
                {autoScrollEnabled ? <Lock className="w-2.5 h-2.5" /> : <Unlock className="w-2.5 h-2.5" />}
                <span>Auto-scroll: {autoScrollEnabled ? 'ON' : 'OFF'}</span>
              </button>

              <button
                type="button"
                onClick={() => setTryFirstMode(!tryFirstMode)}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold transition cursor-pointer border ${
                  tryFirstMode
                    ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/40 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
                title="When enabled, Doubt Dost gives hints and lets you attempt before giving the full answer"
              >
                <Lightbulb className={`w-3.5 h-3.5 ${tryFirstMode ? 'text-amber-500' : ''}`} />
                <span>Try first: {tryFirstMode ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>

          {/* 3. Input Form with Stop Generating Button */}
          <form onSubmit={handleSubmit} className="relative flex items-center">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Ask DoubtDost (${currentModelOption.name})... e.g. "Explain Snell's law in simple Tamil"`}
              disabled={isStreaming}
              className="w-full pl-4 pr-24 py-3 rounded-2xl border border-slate-300/80 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/80 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/40 shadow-inner"
            />

            <div className="absolute right-2 flex items-center gap-1.5">
              {isStreaming ? (
                <button
                  type="button"
                  onClick={onStopStreaming}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition cursor-pointer shadow-sm"
                >
                  <StopCircle className="w-3.5 h-3.5" />
                  <span>Stop</span>
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="p-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white transition cursor-pointer disabled:opacity-40 shadow-md shadow-teal-500/20"
                >
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>
          </form>

          {/* Notes active indicator */}
          {notes && notes.length > 0 && (
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between px-1">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                <span>
                  Grounding active with {notes.length} uploaded note file{notes.length > 1 ? 's' : ''}
                </span>
              </span>
              <span className="text-slate-400">TruthCheck Agent active</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
