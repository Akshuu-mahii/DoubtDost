/**
 * Doubt Dost - Settings & Privacy Control View
 * Local-only privacy guarantee: "Your data is saved only in this browser."
 * Interests, language, pause saving, trusted contact, and complete data purge.
 */

import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Trash2,
  Eye,
  EyeOff,
  User,
  Heart,
  Globe,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserProfile } from '../types';

const INTEREST_CHOICES = [
  '🏏 Cricket',
  '⚽ Football',
  '⚔️ Anime',
  '🎬 Movies',
  '🎵 Music',
  '🎮 Gaming',
  '🍳 Cooking',
  '🎨 Art & Design',
  '✈️ Travel',
  '💻 Tech & Coding',
  '📖 Stories',
  '😂 Memes',
];

export const SettingsView: React.FC = () => {
  const { profile, updateProfile, deleteCurrentChat, deleteAllData } = useApp();

  const [interests, setInterests] = useState<string[]>(profile.interests || []);
  const [pauseSaving, setPauseSaving] = useState<boolean>(profile.pauseSaving || false);
  const [preferredLanguage, setPreferredLanguage] = useState<string>(profile.preferredLanguage || 'Auto-detect');
  const [level, setLevel] = useState<string>(profile.level || 'Class 10');

  // Trusted contact state
  const [contactName, setContactName] = useState<string>(profile.trustedContact?.name || '');
  const [contactPhone, setContactPhone] = useState<string>(profile.trustedContact?.phone || '');
  const [contactRel, setContactRel] = useState<string>(profile.trustedContact?.relationship || 'Parent');

  const [savingNotice, setSavingNotice] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);

  const toggleInterest = (item: string) => {
    const updated = interests.includes(item) ? interests.filter((i) => i !== item) : [...interests, item];
    setInterests(updated);
    updateProfile({ interests: updated });
    triggerNotice('✓ Interests updated');
  };

  const triggerNotice = (msg: string) => {
    setSavingNotice(msg);
    setTimeout(() => setSavingNotice(null), 2000);
  };

  const handleSaveContact = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      trustedContact: {
        name: contactName.trim(),
        phone: contactPhone.trim(),
        relationship: contactRel.trim(),
      },
    });
    triggerNotice('✓ Trusted contact saved');
  };

  const handleLanguageChange = (lang: string) => {
    setPreferredLanguage(lang);
    updateProfile({ preferredLanguage: lang });
    triggerNotice('✓ Language preference saved');
  };

  const handleLevelChange = (lvl: string) => {
    setLevel(lvl);
    updateProfile({ level: lvl });
    triggerNotice('✓ Study level updated');
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Settings & Privacy
            </h1>
            <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Doubt Dost runs directly in your browser with zero remote accounts or tracking.
            </p>
          </div>
          {savingNotice && (
            <span className="text-xs font-semibold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40 px-3 py-1 rounded-full border border-teal-200 dark:border-teal-800">
              {savingNotice}
            </span>
          )}
        </div>

        {/* 1. Privacy Banner Card */}
        <div className="p-5 rounded-3xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-800/50 space-y-2">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <h3 className="font-bold text-sm text-teal-950 dark:text-teal-200">
              Your data is saved only in this browser.
            </h3>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            All your chat logs, diagnostic quiz results, notes, and study plans are stored strictly inside your browser&apos;s
            local storage. No data ever leaves your device to any external server or tracking database.
          </p>
        </div>

        {/* 2. Incognito Mode: Pause Saving */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              {pauseSaving ? (
                <EyeOff className="w-4 h-4 text-amber-500" />
              ) : (
                <Eye className="w-4 h-4 text-teal-600" />
              )}
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Pause Saving (Incognito Study)</h4>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md">
              When turned on, lessons, chats, and quiz scores during this session will not be saved to browser history.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              const newVal = !pauseSaving;
              setPauseSaving(newVal);
              updateProfile({ pauseSaving: newVal });
              triggerNotice(newVal ? 'Incognito mode activated' : 'Saving resumed');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer border ${
              pauseSaving
                ? 'bg-amber-500 text-white border-amber-500'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
            }`}
          >
            {pauseSaving ? 'Paused (ON)' : 'Active (OFF)'}
          </button>
        </div>

        {/* 3. Language & Level Settings */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-teal-600" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Language & Study Level</h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Preferred Language
              </label>
              <select
                value={preferredLanguage}
                onChange={(e) => handleLanguageChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/40"
              >
                <option value="Auto-detect">Auto-detect (Replies in the language you type)</option>
                <option value="English">English</option>
                <option value="Tamil">தமிழ் (Tamil)</option>
                <option value="Tanglish">Tanglish (Tamil + English)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Current Class / Level
              </label>
              <select
                value={level}
                onChange={(e) => handleLevelChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/40"
              >
                <option value="Class 9-10 (Secondary)">Class 9-10 (Secondary)</option>
                <option value="Class 11-12 / HSC (Higher Secondary)">Class 11-12 / HSC (Higher Secondary)</option>
                <option value="College / Engineering / Science">College / Engineering / Science</option>
                <option value="Competitive Exam Prep (NEET / JEE / UPSC)">Competitive Exam Prep (NEET / JEE / UPSC)</option>
                <option value="General / Self-directed Learner">General / Self-directed Learner</option>
              </select>
            </div>
          </div>
        </div>

        {/* 4. Interests Selector */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-rose-500" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Your Interests & Analogies</h4>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Doubt Dost weaves analogies from these topics into your lessons:
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            {INTEREST_CHOICES.map((choice) => {
              const active = interests.includes(choice);
              return (
                <button
                  key={choice}
                  type="button"
                  onClick={() => toggleInterest(choice)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer border ${
                    active
                      ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {choice}
                </button>
              );
            })}
          </div>
        </div>

        {/* 5. Trusted Contact Setup */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-indigo-600" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Trusted Support Contact</h4>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            If you ever feel stressed or low, Doubt Dost can show this person&apos;s phone number for you to reach out to.
          </p>

          <form onSubmit={handleSaveContact} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <input
              type="text"
              value={contactName}
              onChange={(e) => setContactName(e.target.value)}
              placeholder="Contact Name (e.g. Mom, Ravi)"
              className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/40"
            />
            <input
              type="tel"
              value={contactPhone}
              onChange={(e) => setContactPhone(e.target.value)}
              placeholder="Phone Number"
              className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/40"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition cursor-pointer"
            >
              Save Contact
            </button>
          </form>
        </div>

        {/* 6. Purge Data & Reset */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-amber-300/80 dark:border-amber-700/60 space-y-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Data Management & Reset</h4>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <button
              type="button"
              onClick={deleteCurrentChat}
              className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              Delete Current Chat
            </button>

            <button
              type="button"
              onClick={() => setShowDeleteConfirm(true)}
              className="px-3.5 py-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-900 dark:text-amber-300 text-xs font-bold hover:bg-amber-500/25 transition cursor-pointer flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete All My Data</span>
            </button>
          </div>
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-amber-400 dark:border-amber-600 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Delete all your learning data?</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                This will reset your browser storage. All chats, notes, quiz scores, and mistakes will be completely
                cleared. This action cannot be undone.
              </p>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    deleteAllData();
                    setShowDeleteConfirm(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition cursor-pointer"
                >
                  Yes, Delete Everything
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
