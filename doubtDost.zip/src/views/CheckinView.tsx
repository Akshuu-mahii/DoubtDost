/**
 * Doubt Dost - Friend & Mood Check-in View
 * Emotional wellness check-in with mood emoji buttons and adaptive replies.
 * Prominently displays: "I'm an AI learning companion, not a therapist or doctor."
 * Runs safety checks to suggest talking to a trusted person if distress is detected.
 */

import React, { useState } from 'react';
import { HeartHandshake, Send, Sparkles, Shield, Info, PhoneCall } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { runFastSafetyCheck } from '../services/gemini';

const MOODS = [
  { emoji: '🌟', label: 'Energized & Focused', desc: 'Ready to tackle tough problems' },
  { emoji: '😊', label: 'Good & Calm', desc: 'Steady learning state' },
  { emoji: '😐', label: 'Okay / Neutral', desc: 'Going through the lessons' },
  { emoji: '😓', label: 'Overwhelmed', desc: 'Too many assignments or tests' },
  { emoji: '😔', label: 'Down / Low', desc: 'Feeling tired or discouraged' },
  { emoji: '😤', label: 'Frustrated', desc: 'A concept is not clicking yet' },
];

interface CheckinViewProps {
  onDistressDetected?: (message: string) => void;
}

export const CheckinView: React.FC<CheckinViewProps> = ({ onDistressDetected }) => {
  const { profile, checkins, addCheckin, logAgentAction } = useApp();

  const [selectedMood, setSelectedMood] = useState<string>('😊');
  const [selectedLabel, setSelectedLabel] = useState<string>('Good & Calm');
  const [note, setNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [latestReply, setLatestReply] = useState<string | null>(null);

  const handleSubmitCheckin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Fast distress check
    const safetyCheck = runFastSafetyCheck(note);
    if (safetyCheck.distressed && safetyCheck.warmMessage) {
      onDistressDetected?.(safetyCheck.warmMessage);
      logAgentAction('Safety Agent', 'Distress intervention triggered from mood check-in.');
    }

    try {
      const reply = addCheckin(selectedMood, selectedLabel, note.trim());
      setLatestReply(reply);
      logAgentAction('Friend Agent', `Check-in recorded: ${selectedMood} ${selectedLabel}`);
      setNote('');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Check if multiple recent checkins are heavy moods
  const recentHeavyMoodsCount = checkins.slice(0, 3).filter((c) => ['😓', '😔', '😤'].includes(c.mood)).length;

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-700 dark:text-purple-300 text-xs font-semibold mb-2">
            <HeartHandshake className="w-3.5 h-3.5" />
            Friend & Check-in Agent
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            How are you feeling right now?
          </h1>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Learning is easier when your mind is at ease. Take 30 seconds to check in with yourself.
          </p>
        </div>

        {/* AI Limit Honest Disclosure Banner */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-850/60 border border-slate-200/80 dark:border-slate-800 flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-400">
          <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <span>
            <strong>Honest AI Boundary:</strong> I&apos;m an AI learning companion, not a therapist or doctor. I
            cannot feel human emotions, but I am programmed to support your study rhythm with patience and kindness.
          </span>
        </div>

        {/* Gentle suggestion after repeated heavy moods */}
        {recentHeavyMoodsCount >= 2 && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs leading-relaxed space-y-1.5">
            <strong>Gentle reminder:</strong>
            <p>
              It looks like you&apos;ve been feeling down or overwhelmed across your last few sessions. It is completely
              okay to take a break from studying today. Consider taking a walk, chatting with a friend or family member,
              or reaching out to your teacher.
            </p>
          </div>
        )}

        {/* Mood Selector Card */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {MOODS.map((m) => {
              const isSelected = selectedMood === m.emoji;
              return (
                <button
                  key={m.emoji}
                  type="button"
                  onClick={() => {
                    setSelectedMood(m.emoji);
                    setSelectedLabel(m.label);
                  }}
                  className={`p-3.5 rounded-2xl border transition cursor-pointer text-left flex flex-col justify-between ${
                    isSelected
                      ? 'bg-purple-500/15 border-purple-500 dark:border-purple-400 text-slate-900 dark:text-white shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                  }`}
                >
                  <span className="text-2xl mb-1">{m.emoji}</span>
                  <span className="font-semibold text-xs text-slate-900 dark:text-white">{m.label}</span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{m.desc}</span>
                </button>
              );
            })}
          </div>

          <form onSubmit={handleSubmitCheckin} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Anything on your mind? (Optional)
              </label>
              <textarea
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. Preparing for physics test tomorrow, feeling a bit stressed..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-500/40"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-purple-500/15"
            >
              {isSubmitting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Check In</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Latest Companion Reply */}
        {latestReply && (
          <div className="p-5 rounded-3xl bg-gradient-to-br from-purple-50/70 to-indigo-50/40 dark:from-slate-800/80 dark:to-purple-950/20 border border-purple-200/80 dark:border-purple-800/50 space-y-2 animate-in fade-in">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span className="font-bold text-xs text-purple-900 dark:text-purple-200">Doubt Dost&apos;s Thought</span>
            </div>
            <p className="text-xs md:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">{latestReply}</p>
          </div>
        )}

        {/* Saved Trusted Contact card if available */}
        {profile.trustedContact?.phone && (
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-850/50 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between">
            <div>
              <span className="font-semibold text-slate-700 dark:text-slate-300 block">
                Saved Trusted Person: {profile.trustedContact.name} ({profile.trustedContact.relationship})
              </span>
              <span className="text-slate-500 text-[11px]">{profile.trustedContact.phone}</span>
            </div>
            <a
              href={`tel:${profile.trustedContact.phone}`}
              className="px-3 py-1 rounded-lg bg-teal-500/15 text-teal-700 dark:text-teal-300 font-semibold hover:bg-teal-500/25 transition"
            >
              Call
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
