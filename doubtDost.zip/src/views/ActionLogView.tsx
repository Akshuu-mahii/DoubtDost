/**
 * Doubt Dost - Agent Action Log View
 * Complete audit trail of autonomous agent activities
 * alongside student oversight decisions (Approved / Rejected / Completed).
 */

import React from 'react';
import { ClipboardList, ShieldCheck, Calendar, BookOpen, HelpCircle, CheckCircle, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ActionLogView: React.FC = () => {
  const { actionLogs } = useApp();

  const getAgentIcon = (agentName: string) => {
    switch (agentName.toLowerCase()) {
      case 'planner':
      case 'planner agent':
        return Calendar;
      case 'truthcheck':
      case 'truthcheck agent':
        return ShieldCheck;
      case 'quiz':
      case 'quiz agent':
        return HelpCircle;
      default:
        return BookOpen;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
      <div className="max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Agent Activity Log</h1>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Transparent record of all background agent actions taken with student supervision.
          </p>
        </div>

        {actionLogs.length === 0 ? (
          <div className="p-10 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-xs text-slate-400 space-y-2">
            <ClipboardList className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700" />
            <p>No agent actions logged yet. Agent suggestions and verification steps will appear here in real time.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {actionLogs.map((log) => {
              const Icon = getAgentIcon(log.agentName);
              return (
                <div
                  key={log.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-start gap-3.5 text-xs"
                >
                  <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-bold text-slate-900 dark:text-white">{log.agentName}</span>
                      <span className="text-[11px] text-slate-400">{log.timestamp}</span>
                    </div>

                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{log.actionDescription}</p>

                    <div className="mt-2 flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                          log.status === 'approved'
                            ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30'
                            : log.status === 'rejected'
                            ? 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/30'
                            : 'bg-teal-500/10 text-teal-700 dark:text-teal-300 border border-teal-500/30'
                        }`}
                      >
                        {log.status}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
