/**
 * Doubt Dost - Weekly Study Plan & Planner Agent View
 * Student oversight: planner tasks must be explicitly Approved, Edited, or Rejected.
 * Stored locally in this browser.
 */

import React, { useState } from 'react';
import { Calendar, Plus, CheckCircle, Clock, Trash2, CheckCircle2, Sparkles, X, Edit2 } from 'lucide-react';
import { StudyPlanItem } from '../types';
import { useApp } from '../context/AppContext';

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export const StudyPlanView: React.FC = () => {
  const { studyPlan, addPlanTask, approvePlanTask, rejectPlanTask, togglePlanTask, deletePlanTask } = useApp();

  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [topic, setTopic] = useState<string>('');
  const [task, setTask] = useState<string>('');
  const [day, setDay] = useState<string>('Today');

  // Edit task modal
  const [editingTask, setEditingTask] = useState<StudyPlanItem | null>(null);
  const [editTopic, setEditTopic] = useState<string>('');
  const [editTaskText, setEditTaskText] = useState<string>('');
  const [editDay, setEditDay] = useState<string>('Today');

  const pendingSuggestions = studyPlan.filter((s) => !s.approved && s.origin === 'planner_agent');
  const activeTasks = studyPlan.filter((s) => s.approved || s.origin === 'user');

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic || !task) return;
    addPlanTask({
      day,
      topic,
      task,
      status: 'pending',
      approved: true,
      origin: 'user',
    });
    setTopic('');
    setTask('');
    setShowAddModal(false);
  };

  const handleOpenEdit = (item: StudyPlanItem) => {
    setEditingTask(item);
    setEditTopic(item.topic);
    setEditTaskText(item.task);
    setEditDay(item.day);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask) return;
    // Replace with edited approved version
    rejectPlanTask(editingTask.id);
    addPlanTask({
      day: editDay,
      topic: editTopic,
      task: editTaskText,
      status: 'pending',
      approved: true,
      origin: 'planner_agent',
    });
    setEditingTask(null);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Personal Study Plan & Revision
            </h1>
            <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Student-controlled study calendar. The Planner Agent suggests revision tasks from weak quiz concepts; you
              can Approve, Edit, or Reject them.
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs transition cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Study Target</span>
          </button>
        </div>

        {/* Planner Agent Pending Suggestions with Approve / Edit / Reject */}
        {pendingSuggestions.length > 0 && (
          <div className="p-4 rounded-3xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <h3 className="font-bold text-sm text-indigo-950 dark:text-indigo-200">
                Planner Agent Suggestions ({pendingSuggestions.length})
              </h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Generated from weak concepts detected in your recent quizzes. Review and approve before they enter your calendar:
            </p>

            <div className="space-y-2">
              {pendingSuggestions.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-900/60 flex flex-wrap items-center justify-between gap-3 text-xs"
                >
                  <div className="flex-1 min-w-[200px]">
                    <span className="font-semibold text-teal-600 dark:text-teal-400 mr-2">{item.topic}</span>
                    <span className="text-slate-700 dark:text-slate-200">{item.task}</span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">Proposed Day: {item.day}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => approvePlanTask(item.id)}
                      className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold transition cursor-pointer"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleOpenEdit(item)}
                      className="px-2.5 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition cursor-pointer flex items-center gap-1"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => rejectPlanTask(item.id)}
                      className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Weekly Schedule View */}
        <div className="space-y-4">
          <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-teal-600" />
            <span>Weekly Roadmap</span>
          </h3>

          {activeTasks.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-xs text-slate-400">
              No tasks scheduled yet. Click &quot;Add Study Target&quot; or complete a diagnostic quiz to receive smart
              spaced repetition reminders!
            </div>
          ) : (
            <div className="space-y-2.5">
              {activeTasks.map((taskItem) => {
                const isDone = taskItem.status === 'completed';
                return (
                  <div
                    key={taskItem.id}
                    className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 text-xs ${
                      isDone
                        ? 'bg-slate-50 dark:bg-slate-850/50 border-slate-200 dark:border-slate-800 opacity-60'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => togglePlanTask(taskItem.id)}
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                          isDone
                            ? 'bg-teal-600 border-teal-600 text-white'
                            : 'border-slate-300 dark:border-slate-700 hover:border-teal-500'
                        }`}
                      >
                        {isDone && <CheckCircle className="w-3.5 h-3.5" />}
                      </button>

                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-semibold text-sm ${
                              isDone ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                            }`}
                          >
                            {taskItem.topic}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300">
                            {taskItem.day}
                          </span>
                        </div>
                        <p className={`text-slate-600 dark:text-slate-400 mt-0.5 ${isDone ? 'line-through' : ''}`}>
                          {taskItem.task}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => deletePlanTask(taskItem.id)}
                      className="p-1.5 text-slate-400 hover:text-amber-600 transition cursor-pointer"
                      title="Delete task"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Add Study Target</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Topic / Subject</label>
                <input
                  type="text"
                  required
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g. Physics: Electromagnetic Induction"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Target / Task</label>
                <input
                  type="text"
                  required
                  value={task}
                  onChange={(e) => setTask(e.target.value)}
                  placeholder="e.g. Solve 5 worked examples and review Faraday laws"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Day / Time</label>
                <select
                  value={day}
                  onChange={(e) => setDay(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                >
                  <option value="Today">Today</option>
                  <option value="Tomorrow">Tomorrow</option>
                  {DAYS_OF_WEEK.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold cursor-pointer"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Task Modal */}
      {editingTask && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Edit Suggested Task</h3>
              <button
                onClick={() => setEditingTask(null)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Topic</label>
                <input
                  type="text"
                  required
                  value={editTopic}
                  onChange={(e) => setEditTopic(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Task</label>
                <input
                  type="text"
                  required
                  value={editTaskText}
                  onChange={(e) => setEditTaskText(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Day</label>
                <select
                  value={editDay}
                  onChange={(e) => setEditDay(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                >
                  <option value="Today">Today</option>
                  <option value="Tomorrow">Tomorrow</option>
                  {DAYS_OF_WEEK.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingTask(null)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold cursor-pointer"
                >
                  Save & Approve
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
