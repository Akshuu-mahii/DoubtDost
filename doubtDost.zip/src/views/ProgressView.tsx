/**
 * Doubt Dost - Progress & Mastery View
 * Chart.js before/after confidence trends, diagnostic quiz scores, streak, badges,
 * weak concepts breakdown, Mistake Notebook, and private mood trend.
 * Completely empty until real student activity occurs in this browser!
 */

import React, { useState } from 'react';
import {
  TrendingUp,
  Award,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Smile,
  BarChart2,
  Trash2,
  Sparkles,
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';
import { useApp } from '../context/AppContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const ProgressView: React.FC = () => {
  const { quizzes, mistakes, checkins, messages, reviewMistake, deleteMistake } = useApp();
  const [activeTab, setActiveTab] = useState<'overview' | 'mistakes' | 'mood'>('overview');

  const doubtsSolvedCount = messages.filter((m) => m.role === 'user').length;
  const hasActivity = quizzes.length > 0 || mistakes.length > 0 || doubtsSolvedCount > 0;

  // Confidence before vs after Chart data
  const confidenceLabels = quizzes.map((q, idx) => `Q${idx + 1}: ${q.topic.slice(0, 10)}`);
  const confidenceData = {
    labels: confidenceLabels.length > 0 ? confidenceLabels : ['No quizzes yet'],
    datasets: [
      {
        label: 'Before Lesson Confidence (1-5 ⭐)',
        data: quizzes.map((q) => q.beforeConfidence),
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        tension: 0.3,
        fill: true,
      },
      {
        label: 'After Lesson Confidence (1-5 ⭐)',
        data: quizzes.map((q) => q.afterConfidence),
        borderColor: '#0d9488',
        backgroundColor: 'rgba(13, 148, 136, 0.2)',
        tension: 0.3,
        fill: true,
      },
    ],
  };

  // Badges based strictly on real activity
  const badges = [
    {
      id: 'first_doubt',
      title: 'First Doubt Asked',
      desc: 'Asked your first doubt to Doubt Dost',
      earned: doubtsSolvedCount >= 1,
      icon: '🌱',
    },
    {
      id: 'five_doubts',
      title: 'Curious Scholar',
      desc: 'Asked 5 or more doubts across sessions',
      earned: doubtsSolvedCount >= 5,
      icon: '⚡',
    },
    {
      id: 'first_quiz',
      title: 'Diagnostic Pioneer',
      desc: 'Completed your first 8-question quiz',
      earned: quizzes.length >= 1,
      icon: '🎯',
    },
    {
      id: 'quiz_master',
      title: 'Concept Master',
      desc: 'Scored 80%+ on any topic quiz',
      earned: quizzes.some((q) => q.score / q.totalQuestions >= 0.8),
      icon: '🏆',
    },
    {
      id: 'mistake_learner',
      title: 'Mistake Master',
      desc: 'Reviewed and corrected a mistake in the Notebook',
      earned: mistakes.some((m) => m.reviewed),
      icon: '🧠',
    },
  ];

  const averageScore =
    quizzes.length > 0
      ? Math.round(
          (quizzes.reduce((acc, q) => acc + (q.score / q.totalQuestions) * 100, 0) / quizzes.length)
        )
      : 0;

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Learning Progress & Mastery
            </h1>
            <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Live metrics and diagnostic curves calculated from your browser activity.
            </p>
          </div>

          {/* Sub-nav Tabs */}
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-medium">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 font-semibold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Overview & Charts
            </button>
            <button
              onClick={() => setActiveTab('mistakes')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'mistakes'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 font-semibold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <span>Mistake Notebook</span>
              {mistakes.filter((m) => !m.reviewed).length > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {mistakes.filter((m) => !m.reviewed).length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('mood')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                activeTab === 'mood'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 font-semibold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Private Mood Trend
            </button>
          </div>
        </div>

        {!hasActivity ? (
          /* Empty state - zero pre-filled fake data! */
          <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <TrendingUp className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">No Learning Activity Recorded Yet</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto leading-relaxed">
              Your doubts solved, diagnostic quiz scores, before vs after confidence comparisons, and mistake notebook
              will appear here as you ask doubts and take quizzes.
            </p>
          </div>
        ) : (
          <>
            {/* OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Metric Summary Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                      Doubts Solved
                    </span>
                    <span className="text-2xl font-extrabold text-teal-600 dark:text-teal-400">{doubtsSolvedCount}</span>
                  </div>
                  <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                      Quizzes Taken
                    </span>
                    <span className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
                      {quizzes.length}
                    </span>
                  </div>
                  <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                      Avg Quiz Score
                    </span>
                    <span className="text-2xl font-extrabold text-slate-900 dark:text-white">{averageScore}%</span>
                  </div>
                  <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                      Mistakes to Review
                    </span>
                    <span className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">
                      {mistakes.filter((m) => !m.reviewed).length}
                    </span>
                  </div>
                </div>

                {/* Confidence Before vs After Chart */}
                {quizzes.length > 0 && (
                  <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                          Confidence Shift (Before vs After Lesson Quiz)
                        </h3>
                        <p className="text-[11px] text-slate-500">
                          Tracks how testing your understanding improved your confidence on a 1-5 scale.
                        </p>
                      </div>
                      <BarChart2 className="w-4 h-4 text-teal-500" />
                    </div>
                    <div className="h-64 w-full">
                      <Line
                        data={confidenceData}
                        options={{
                          responsive: true,
                          maintainAspectRatio: false,
                          scales: {
                            y: {
                              min: 1,
                              max: 5,
                              ticks: { stepSize: 1 },
                            },
                          },
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* Badges Section */}
                <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-500" />
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">Mastery Badges</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {badges.map((b) => (
                      <div
                        key={b.id}
                        className={`p-3.5 rounded-2xl border transition flex items-start gap-3 ${
                          b.earned
                            ? 'bg-gradient-to-br from-amber-50/50 to-teal-50/40 dark:from-slate-800 dark:to-teal-950/20 border-amber-300/80 dark:border-amber-700/60 shadow-sm'
                            : 'bg-slate-50/60 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 opacity-50 grayscale'
                        }`}
                      >
                        <span className="text-2xl shrink-0">{b.icon}</span>
                        <div>
                          <h4 className="font-bold text-xs text-slate-900 dark:text-white">{b.title}</h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{b.desc}</p>
                          {b.earned && (
                            <span className="inline-block mt-1 text-[10px] text-teal-700 dark:text-teal-300 font-semibold">
                              ✓ Earned
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* MISTAKES NOTEBOOK TAB */}
            {activeTab === 'mistakes' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    Mistake Notebook ({mistakes.length})
                  </h3>
                  <span className="text-xs text-slate-500">
                    Weak concepts captured during diagnostic quizzes for targeted revision.
                  </span>
                </div>

                {mistakes.length === 0 ? (
                  <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-400">
                    No mistakes logged! You answered correctly on your recent quizzes.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {mistakes.map((m) => (
                      <div
                        key={m.id}
                        className={`p-4 rounded-2xl border transition space-y-2 ${
                          m.reviewed
                            ? 'bg-slate-50/70 dark:bg-slate-850/40 border-slate-200 dark:border-slate-800 opacity-70'
                            : 'bg-white dark:bg-slate-900 border-amber-300/70 dark:border-amber-800/60 shadow-sm'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-teal-600 dark:text-teal-400">{m.topic}</span>
                          <span className="text-slate-400 text-[11px]">{m.date}</span>
                        </div>

                        <p className="font-medium text-sm text-slate-900 dark:text-white">{m.question}</p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-900 dark:text-amber-200">
                            <strong>Your Answer:</strong> {m.userAnswer}
                          </div>
                          <div className="p-2 rounded-xl bg-teal-500/10 text-teal-900 dark:text-teal-200">
                            <strong>Correct Answer:</strong> {m.correctAnswer}
                          </div>
                        </div>

                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800">
                          {m.explanation}
                        </p>

                        <div className="flex items-center justify-between pt-1">
                          <button
                            onClick={() => reviewMistake(m.id)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                              m.reviewed
                                ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                                : 'bg-teal-600 hover:bg-teal-500 text-white'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{m.reviewed ? 'Reviewed ✓' : 'Mark as Reviewed'}</span>
                          </button>

                          <button
                            onClick={() => deleteMistake(m.id)}
                            className="p-1.5 text-slate-400 hover:text-amber-600 transition cursor-pointer"
                            title="Remove from notebook"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* MOOD TREND TAB (Visible only to the student!) */}
            {activeTab === 'mood' && (
              <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Smile className="w-4 h-4 text-purple-500" />
                    <span>Private Mood History</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Saved strictly in this browser. Never transmitted or shared with anyone.
                  </p>
                </div>

                {checkins.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400">
                    No check-ins logged yet. Visit the Friend & Mood tab to check in today!
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {checkins.slice(0, 10).map((c) => (
                      <div
                        key={c.id}
                        className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-2xl">{c.mood}</span>
                          <div>
                            <span className="font-semibold text-slate-800 dark:text-slate-200">{c.moodLabel}</span>
                            {c.note && <p className="text-slate-500 dark:text-slate-400 mt-0.5">{c.note}</p>}
                          </div>
                        </div>
                        <span className="text-slate-400 text-[11px]">{new Date(c.timestamp).toLocaleDateString()}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
