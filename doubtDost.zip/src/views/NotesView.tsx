/**
 * Doubt Dost - Notes & Grounding View
 * Upload PDFs, text notes, or paste textbook snippets.
 * Chunks notes into 250-word passages and performs browser-side keyword retrieval
 * to ground every lesson in your exact syllabus.
 */

import React, { useState } from 'react';
import { Upload, FileText, CheckCircle2, Trash2, Plus, Sparkles, BookOpen, Layers } from 'lucide-react';
import { UserNote } from '../types';
import { useApp } from '../context/AppContext';

export const NotesView: React.FC = () => {
  const { notes, addNote, deleteNote } = useApp();
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setTitle(file.name.replace(/\.[^/.]+$/, ''));
    const reader = new FileReader();

    reader.onload = async (event) => {
      const result = event.target?.result;
      if (typeof result === 'string') {
        setContent(result);
      } else if (result instanceof ArrayBuffer) {
        // Attempt basic text extraction from binary buffers (PDF/DOC)
        const decoder = new TextDecoder('utf-8');
        const rawText = decoder.decode(result);
        // Strip non-printable control characters
        const cleaned = rawText
          .replace(/[^\x20-\x7E\n\r\t]/g, ' ')
          .replace(/\s{2,}/g, ' ')
          .trim();
        setContent(cleaned || 'Uploaded binary document. Please review extracted content above.');
      }
    };

    if (file.name.endsWith('.pdf')) {
      reader.readAsArrayBuffer(file);
    } else {
      reader.readAsText(file);
    }
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setIsProcessing(true);
    try {
      addNote(title.trim(), content.trim(), 'note', content.length);
      setTitle('');
      setContent('');
      setShowUploadModal(false);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Study Notes & Syllabus Grounding
            </h1>
            <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Upload your school/college textbook notes, syllabus PDFs, or handouts. Doubt Dost will ground every answer
              in your exact class notes!
            </p>
          </div>

          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs transition cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Upload or Paste Notes</span>
          </button>
        </div>

        {/* Informational Grounding Card */}
        <div className="p-4 rounded-3xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-800/60 flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed space-y-1">
            <strong className="text-teal-950 dark:text-teal-200 block">
              Browser-Side RAG & TruthCheck Grounding:
            </strong>
            <p className="text-slate-600 dark:text-slate-300">
              When you ask a doubt, Doubt Dost searches through your notes in the browser and retrieves the top 3-4
              matching chunks. The TruthCheck agent verifies that formulas and definitions match your uploaded notes
              so you score full marks in your exams.
            </p>
          </div>
        </div>

        {/* Uploaded Notes List */}
        <div className="space-y-4">
          <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-teal-600" />
            <span>Indexed Notes ({notes.length})</span>
          </h3>

          {notes.length === 0 ? (
            <div className="p-10 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                <Upload className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">No Notes Uploaded Yet</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                Without notes, Doubt Dost provides general curriculum answers. Upload your class notes or copy-paste
                textbook snippets to enable strict grounding!
              </p>
              <button
                onClick={() => setShowUploadModal(true)}
                className="mt-2 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs transition cursor-pointer"
              >
                Upload First Note
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {notes.map((note) => (
                <div
                  key={note.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                      <span className="px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-700 dark:text-teal-300 font-medium text-[10px]">
                        {note.chunksCount || note.chunks?.length || 1} Chunks Indexed
                      </span>
                      <span>{note.uploadedAt}</span>
                    </div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">{note.title}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-3 leading-relaxed">
                      {note.content}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Ready for Grounding
                    </span>

                    <button
                      onClick={() => deleteNote(note.id)}
                      className="p-1.5 text-slate-400 hover:text-amber-600 transition cursor-pointer"
                      title="Remove note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Upload or Paste Notes</h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Upload PDF or Text File (.pdf, .txt, .md)
                </label>
                <input
                  type="file"
                  accept=".txt,.md,.pdf"
                  onChange={handleFileUpload}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-teal-50 file:text-teal-700 hover:file:bg-teal-100 cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Note Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Physics Chapter 3: Laws of Motion"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Note Content (Type or paste notes here)
                </label>
                <textarea
                  required
                  rows={8}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Paste textbook definitions, formulas, or teacher handouts here..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-teal-500/40 font-mono leading-relaxed"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold cursor-pointer disabled:opacity-50"
                >
                  {isProcessing ? 'Indexing...' : 'Index Note in Browser'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
