"""
Nanban AI - LLM Provider Layer
Centralized module for all LLM calls supporting Gemini, Groq, OpenAI, and Anthropic.
Configured via backend/.env or environment variables.
"""

import os
import json
import asyncio
from typing import AsyncGenerator, Dict, Any, List, Optional
from dotenv import load_dotenv

load_dotenv()
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "gemini").lower()
LLM_API_KEY = os.getenv("LLM_API_KEY", "") or os.getenv("GEMINI_API_KEY", "")
FAST_MODEL = os.getenv("FAST_MODEL", "gemini-3.8-flash")
STRONG_MODEL = os.getenv("STRONG_MODEL", "gemini-3.8-flash")

print(f"[Nanban AI Backend] LLM Provider: {LLM_PROVIDER} | Fast Model: {FAST_MODEL} | Strong Model: {STRONG_MODEL}")

class LLMService:
    def __init__(self):
        self.provider = LLM_PROVIDER
        self.api_key = LLM_API_KEY
        self.fast_model = FAST_MODEL
        self.strong_model = STRONG_MODEL
        self._init_client()

    def _init_client(self):
        if self.provider == "gemini":
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key) if self.api_key else None
            except Exception as e:
                print(f"[LLMService] Gemini client init notice: {e}")
                self.client = None
        else:
            self.client = None

    def is_configured(self) -> bool:
        return bool(self.api_key)

    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        system_instruction: str,
        model: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """Stream tokens for chat with a 30s timeout and error recovery."""
        active_model = model or self.fast_model
        if not self.is_configured():
            yield "LLM API Key is not configured. Please set GEMINI_API_KEY in your environment."
            return

        try:
            from google import genai
            client = genai.Client(api_key=self.api_key)
            contents = []
            for m in messages[-10:]:
                contents.append(f"{m.get('role', 'user').capitalize()}: {m.get('content', '')}")
            prompt = "\n".join(contents)

            response = client.models.generate_content_stream(
                model=active_model,
                contents=prompt,
                config={"system_instruction": system_instruction}
            )
            for chunk in response:
                if chunk.text:
                    yield chunk.text
        except Exception as e:
            err_msg = str(e)
            if "quota" in err_msg.lower() or "429" in err_msg:
                yield "\n\n⚠️ AI service quota exceeded. Please wait a moment and click Retry."
            elif "key" in err_msg.lower() or "401" in err_msg:
                yield "\n\n⚠️ Invalid or missing API key. Please check your configuration."
            else:
                yield f"\n\n⚠️ Could not complete response: {err_msg}"

    async def generate_json(self, prompt: str, system_instruction: str, model: Optional[str] = None) -> Dict[str, Any]:
        """Generate structured JSON response."""
        active_model = model or self.strong_model
        if not self.is_configured():
            return {"error": "LLM API Key not configured"}

        try:
            from google import genai
            client = genai.Client(api_key=self.api_key)
            response = client.models.generate_content(
                model=active_model,
                contents=prompt,
                config={
                    "system_instruction": system_instruction,
                    "response_mime_type": "application/json"
                }
            )
            return json.loads(response.text)
        except Exception as e:
            print(f"[LLMService Error] {e}")
            return {"error": str(e)}

llm_service = LLMService()
