"""
Nanban AI - FastAPI Backend Server
Provides health checks, SSE chat streaming, quiz generation, notes RAG, truth-check, and safety endpoints.
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import json
import asyncio
from backend.llm import llm_service, LLM_PROVIDER, FAST_MODEL, STRONG_MODEL

app = FastAPI(title="Nanban AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "llm_configured": llm_service.is_configured(),
        "provider": LLM_PROVIDER,
        "fast_model": FAST_MODEL,
        "strong_model": STRONG_MODEL
    }

@app.post("/api/chat/stream")
async def chat_stream(request: Request):
    data = await request.json()
    messages = data.get("messages", [])
    style = data.get("style", "Detailed lesson")
    notes_context = data.get("notes_context", "")
    language = data.get("language", "Auto-detect")
    try_first = data.get("try_first", False)
    level = data.get("level", "High School")

    system_prompt = f"""You are Nanban AI, a kind, highly capable, student-controlled multi-agent AI learning companion.
Current student level: {level}
Answer style: {style}
Preferred language setting: {language}
Try-first mode active: {try_first}

CRITICAL RULES:
1. Auto-detect the student's language (English, Tamil, Tanglish, or mixed) and reply in the EXACT same language and warm, encouraging tone. Switch smoothly whenever the student switches.
2. If Try-first mode is TRUE:
   - Do NOT give the direct answer yet!
   - Ask the student to share what they think or attempt the first step.
   - Provide 1 encouraging gentle hint.
   - Let them know they can type their attempt or click 'Show full answer'.
3. If Detailed lesson is requested:
   Structure the response cleanly with Markdown:
   ### 1. One-Line Simple Definition
   ### 2. Why It Matters & Real-Life Use
   ### 3. Step-by-Step Core Concepts (simple everyday analogy first, then technical terms)
   ### 4. Worked Examples
   ### 5. Comparison Table (where applicable)
   ### 6. Diagram or Flow Description (ASCII, Mermaid or step flow)
   ### 7. Common Mistakes & Exam Tips
   ### 8. Quick Recap (3-5 bullet points)
4. Marks-based answers (2-mark, 5-mark, 10-mark) must be structured strictly to exam requirements (concise key points with marks distribution, headings, underlined keywords).
5. Grounding: If notes context is provided below, prioritize it and refer to it. If not provided, state naturally that this is a general explanation.
Notes context:
{notes_context if notes_context else "None provided (general answer)."}
"""

    async def event_generator():
        async for token in llm_service.stream_chat(messages, system_prompt):
            yield f"data: {json.dumps({'text': token})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
